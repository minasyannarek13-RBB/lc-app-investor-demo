(() => {
  "use strict";
  const state = {
    client: null,
    profile: null,
    personas: [],
    current: null,
    player: null,
    creator: null,
    industry: null,
    sessions: [],
    creators: [],
    posts: [],
    follows: /* @__PURE__ */ new Set(),
    creatorLiveAlerts: /* @__PURE__ */ new Map(),
    reminders: /* @__PURE__ */ new Set(),
    notifications: [],
    returnSignalsAvailable: !0,
    creatorLiveAlertsAvailable: !0,
    liveSignalsEnabled: !0,
    accessRequests: [],
    pilotBriefs: [],
    pilotBriefsAvailable: !0,
    blockedIds: /* @__PURE__ */ new Set(),
    blockedProfiles: [],
    selectedCreator: null,
    selectedSession: null,
    search: "",
    discoveryFilter: "for_you",
    socialView: "home",
    creatorStudioView: "overview",
    businessView: "overview",
    demo: !1,
    demoPersona: null,
    busy: !1,
    ready: !1,
    loadError: null,
    retrying: !1,
    analyticsAvailable: !0,
    eventDedupe: /* @__PURE__ */ new Set(),
    handoffDestinations: /* @__PURE__ */ new Map()
  }, games = ["Blackjack", "Baccarat", "Roulette", "Poker", "Game Show"], languages = ["English", "French", "Italian", "Spanish", "Armenian"], interests = ["creator network", "player discovery", "retention/engagement", "live discovery", "integration", "attribution"], REGULATED_BOUNDARY = "The licensed operator keeps gameplay, wallet, KYC/AML, responsible gaming, wagering and settlement.", DATA_BOUNDARY = "No deposits, wagering, KYC, AML, wallet or settlement data passes through LC.", EVIDENCE_BOUNDARY = "These are product hypotheses to validate through integration and pilot data.", CLAIM_BOUNDARY = "LC does not claim proven uplift, revenue or retention.", ATTRIBUTION_KEY_PREFIX = "lc-app:attribution-v1", reportReasons = [["spam", "Spam"], ["abuse", "Abuse or harassment"], ["illegal_content", "Illegal content"], ["other", "Other"]], ATTRIBUTION_MAX_AGE = 720 * 60 * 60 * 1e3, PRODUCT_EVENTS = /* @__PURE__ */ new Set(["product_open", "creator_impression", "discovery_search", "creator_profile_open", "creator_follow", "live_session_open", "schedule_reminder", "handoff_intent", "handoff_return", "notification_response"]), PILOT_EVENTS = [["creator_impression", "Creator impression"], ["creator_profile_open", "Profile open"], ["creator_follow", "Follow"], ["live_session_open", "Live open"], ["schedule_reminder", "Schedule reminder"], ["handoff_intent", "Handoff intent"], ["handoff_return", "Return visit"], ["notification_response", "Signal response"]], PILOT_HYPOTHESES = [["creator_handoff", "Creator-led discovery produces operator handoff intent"], ["creator_return", "Following a Creator contributes to return activity"], ["live_signal_response", "Live signals prompt measurable player response"], ["creator_source_attribution", "Creator source remains attributable through handoff and return"]], investorMode = window.LC_APP_MODE === "public_demo" || new URLSearchParams(window.location.search).get("demo") === "investor", DEMO_EPOCH = Date.UTC(2026, 9, 10, 18, 0), productNow = () => state.demo ? DEMO_EPOCH : Date.now();
  let demoSequence = 0, tourStep = -1;
  const tourScenarios = [
    ["Meet your next dealer", "LC App is a social layer for Live Casino. Meet Blackjack and Baccarat dealers, follow them and return to their tables.", "Explore the lobby"],
    ["Turn discovery into a relationship", "Like a post, leave a comment and follow a dealer. Open their session preview to try the scripted table, room chat and operator-return journey.", "Meet Sofia"],
    ["See the integration value", "Operators can connect discovery to licensed play and measure return journeys. Providers can give existing tables a creator-led distribution channel. These benefits still require pilot validation.", "Inspect operator workspace"]
  ], demoStore = { trace: [], campaign: null, mapping: null, roomMessages: /* @__PURE__ */ new Map(), roomRounds: /* @__PURE__ */ new Map(), roomReactions: /* @__PURE__ */ new Set(), follows: /* @__PURE__ */ new Set(), creatorLiveAlerts: /* @__PURE__ */ new Map(), reminders: /* @__PURE__ */ new Set(), likes: /* @__PURE__ */ new Set(), comments: [], posts: [], sessions: [], sessionOverrides: /* @__PURE__ */ new Map(), notifications: [], requests: /* @__PURE__ */ new Set(), pilotBriefs: [] }, demoProfiles = [
    { id: "demo-sofia", username: "sofia_live", display_name: "Sofia Laurent", avatar_url: "app_prototype_assets/dealers/dealer_sofia_avatar_v1.jpg", bio: "Blackjack dealer building a followable Live Casino audience.", country: "Malta", languages: ["English", "French"] },
    { id: "demo-mia", username: "mia_tables", display_name: "Mia Novak", avatar_url: "app_prototype_assets/dealers/dealer_mia_avatar_v1.jpg", bio: "Roulette and baccarat sessions with a calm table style.", country: "Latvia", languages: ["English", "Italian"] },
    { id: "demo-marcus", username: "marcus_live", display_name: "Marcus Reed", avatar_url: "app_prototype_assets/dealers/dealer_marcus_avatar_v1.jpg", bio: "Game-show host focused on community return visits.", country: "UK", languages: ["English", "Spanish"] },
    { id: "demo-alex", username: "alex_baccarat", display_name: "Alex Moreau", avatar_url: "app_prototype_assets/dealers/v2_polish/alex_portrait.jpg", bio: "Baccarat host connecting premium table rhythm with repeat players.", country: "France", languages: ["English", "French"] },
    { id: "demo-lilit", username: "lilit_cards", display_name: "Lilit Aram", avatar_url: "app_prototype_assets/dealers/dealer_lilit_avatar_v1.jpg", bio: "Blackjack and poker creator focused on clear table explainers.", country: "Armenia", languages: ["English", "Armenian"] }
  ], demoCreators = [
    { user_id: "demo-sofia", headline: "Featured Blackjack creator", games: ["Blackjack", "Baccarat"], languages: ["English", "French"], affiliation_name: "Demo Casino", affiliation_verification_status: "unverified", verification_status: "unverified", profile_status: "published" },
    { user_id: "demo-mia", headline: "Roulette table personality", games: ["Roulette", "Baccarat"], languages: ["English", "Italian"], affiliation_name: "Demo Studio", affiliation_verification_status: "unverified", verification_status: "unverified", profile_status: "published" },
    { user_id: "demo-marcus", headline: "Game Show host", games: ["Game Show"], languages: ["English", "Spanish"], affiliation_name: "Demo Provider", affiliation_verification_status: "unverified", verification_status: "unverified", profile_status: "published" },
    { user_id: "demo-alex", headline: "Baccarat creator for premium sessions", games: ["Baccarat"], languages: ["English", "French"], affiliation_name: "Demo Casino", affiliation_verification_status: "unverified", verification_status: "unverified", profile_status: "published" },
    { user_id: "demo-lilit", headline: "Blackjack and poker table explainer", games: ["Blackjack", "Poker"], languages: ["English", "Armenian"], affiliation_name: "Demo Studio", affiliation_verification_status: "unverified", verification_status: "unverified", profile_status: "published" }
  ], demoSessions = [
    { id: "demo-session-sofia", creator_id: "demo-sofia", title: "Evening Blackjack table", game: "Blackjack", operator_name: "Demo Casino", starts_at: new Date(DEMO_EPOCH + 36e5).toISOString(), status: "scheduled", visibility: "public", provenance: "illustrative_demo_data" },
    { id: "demo-session-mia", creator_id: "demo-mia", title: "Roulette community hour", game: "Roulette", operator_name: "Demo Casino", starts_at: new Date(DEMO_EPOCH + 72e5).toISOString(), status: "scheduled", visibility: "public", provenance: "illustrative_demo_data" },
    { id: "demo-session-marcus", creator_id: "demo-marcus", title: "Game Show warm-up", game: "Game Show", operator_name: "Demo Provider", starts_at: new Date(DEMO_EPOCH + 108e5).toISOString(), status: "scheduled", visibility: "public", provenance: "illustrative_demo_data" },
    { id: "demo-session-alex", creator_id: "demo-alex", title: "Premium Baccarat room", game: "Baccarat", operator_name: "Demo Casino", starts_at: new Date(DEMO_EPOCH + 18e5).toISOString(), status: "scheduled", visibility: "public", provenance: "illustrative_demo_data" },
    { id: "demo-session-lilit", creator_id: "demo-lilit", title: "Blackjack strategy table", game: "Blackjack", operator_name: "Demo Studio", starts_at: new Date(DEMO_EPOCH + 144e5).toISOString(), status: "scheduled", visibility: "public", provenance: "illustrative_demo_data" }
  ], demoPosts = [
    { id: "demo-post-sofia", author_id: "demo-sofia", body: "An example Blackjack session with Sofia. Follow her profile and save a reason to return.", created_at: new Date(DEMO_EPOCH - 9e5).toISOString(), status: "active", deleted_at: null },
    { id: "demo-post-mia", author_id: "demo-mia", body: "Example update: a quieter Roulette and Baccarat session preview. Follow Mia to explore the return journey.", created_at: new Date(DEMO_EPOCH - 36e5).toISOString(), status: "active", deleted_at: null },
    { id: "demo-post-marcus", author_id: "demo-marcus", body: "Example Game Show update. Explore how a creator can bring followers back.", created_at: new Date(DEMO_EPOCH - 54e5).toISOString(), status: "active", deleted_at: null },
    { id: "demo-post-alex", author_id: "demo-alex", body: "Example Baccarat session with Alex. Save the preview and try the local table room.", created_at: new Date(DEMO_EPOCH - 27e5).toISOString(), status: "active", deleted_at: null },
    { id: "demo-post-lilit", author_id: "demo-lilit", body: "Example Blackjack note. Meet Lilit and explore a scheduled preview.", created_at: new Date(DEMO_EPOCH - 72e5).toISOString(), status: "active", deleted_at: null }
  ], visualMedia = {
    "demo-sofia": "app_prototype_assets/dealers/dealer_sofia_avatar_v1.jpg",
    "demo-mia": "app_prototype_assets/dealers/dealer_mia_avatar_v1.jpg",
    "demo-marcus": "app_prototype_assets/dealers/dealer_marcus_avatar_v1.jpg",
    "demo-alex": "app_prototype_assets/dealers/v2_polish/alex_baccarat.jpg",
    "demo-lilit": "app_prototype_assets/dealers/dealer_lilit_avatar_v1.jpg",
    fallback: "app_prototype_assets/dealers/dealer_sofia_avatar_v1.jpg"
  }, q = (selector, root = document) => root.querySelector(selector), qa = (selector, root = document) => Array.from(root.querySelectorAll(selector)), safe = (value) => String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;"
  })[char]), profileName = (profile) => profile?.display_name || profile?.username || "LC App user", avatar = (profile) => {
    const source = profile?.avatar_url || "app-icon-512.png";
    return window.LC_APP_MODE !== "public_demo" ? source : new Set(Object.values(visualMedia).concat("app_prototype_assets/dealers/v2_polish/alex_portrait.jpg")).has(source) ? source.replace(/\.jpg$/, "-avatar.webp") : source;
  }, avatarSizes = (profile, size = 64) => {
    const image = avatar(profile);
    return image.endsWith("-avatar.webp") ? `srcset="${safe(image.replace("-avatar.webp", "-avatar-120.webp"))} 120w, ${safe(image)} 240w" sizes="${size}px"` : "";
  }, toast = (text) => {
    window.LC_APP_MODE === "public_demo" && (text = window.LCDemoLocale?.translate(text) || text), typeof window.showToast == "function" && window.showToast(text);
    const node = q("#toast");
    node && (node.textContent = text, node.classList.add("show"), window.setTimeout(() => node.classList.remove("show"), 1400));
  }, err = (error) => {
    const raw = `${error?.code || ""} ${error?.message || ""}`.toLowerCase();
    return /not_verified/.test(raw) ? "Creator verification and a published profile are required." : /publish_first/.test(raw) ? "Publish this session before going live." : /already_live/.test(raw) ? "End the current Live session before starting another." : /duplicate|23505/.test(raw) ? "Already saved." : /permission|policy|rls|42501|not authorized/.test(raw) ? "This action is not available." : /network|fetch|failed/.test(raw) ? "Connection issue. Try again." : "Something went wrong. Please try again.";
  }, validDemoPersonas = /* @__PURE__ */ new Set(["player", "creator", "operator", "provider", "admin"]), productParts = (target = "") => {
    const parts = (target || window.location.hash.replace(/^#\/?/, "")).split("?")[0].split("&")[0].split("/").filter(Boolean);
    return parts[0] === "product" ? parts.slice(1) : [];
  }, setProductHash = (parts = []) => {
    const next = `#/product${parts.length ? "/" + parts.map(encodeURIComponent).join("/") : ""}`;
    return window.location.hash === next ? !1 : (window.location.hash = next, !0);
  }, resetDemoStore = () => {
    demoSequence = 0, demoStore.trace = [], demoStore.campaign = null, demoStore.mapping = null, demoStore.roomMessages.clear(), demoStore.roomRounds.clear(), demoStore.roomReactions.clear(), demoStore.follows.clear(), demoStore.creatorLiveAlerts.clear(), demoStore.reminders.clear(), demoStore.likes.clear(), demoStore.comments = [], demoStore.posts = [], demoStore.sessions = [], demoStore.sessionOverrides.clear(), demoStore.notifications = [], demoStore.requests.clear(), demoStore.pilotBriefs = [];
  }, isIllustrativeProfile = (profile) => !!profile?.id?.startsWith("demo-"), isIllustrativeSession = (session) => !!(state.demo || session?.provenance === "illustrative_demo_data" || session?.id?.startsWith("demo-")), isPresentedLive = (session) => session?.status === "live" && (!isIllustrativeSession(session) || new Date(session.starts_at).getTime() <= productNow()), isSessionPreview = (session) => !!(session && isIllustrativeSession(session) && (session.status === "scheduled" || new Date(session.starts_at).getTime() > productNow())), sessionStatusLabel = (session) => session ? isSessionPreview(session) ? "SESSION PREVIEW" : session?.status === "live" ? isIllustrativeSession(session) ? "DEMO LIVE" : "LIVE NOW" : session?.status === "scheduled" ? "UPCOMING" : "ENDED" : "NO SESSION", localDateTimeInput = (date) => new Date(date.getTime() - date.getTimezoneOffset() * 6e4).toISOString().slice(0, 16), dateLabel = (value) => {
    const date = new Date(value), ru = document.documentElement.lang === "ru";
    return state.demo && Math.abs(date.getTime() - DEMO_EPOCH) < 864e5 ? `${ru ? "Пример · день 1" : "Sample · Day 1"} · ${date.toLocaleTimeString(ru ? "ru-RU" : "en-GB", { hour: "2-digit", minute: "2-digit", timeZone: "UTC", hour12: !1 })} UTC` : date.toLocaleString(ru ? "ru-RU" : "en-GB", { dateStyle: "medium", timeStyle: "short" });
  }, sessionLine = (session) => `${sessionStatusLabel(session)} · ${dateLabel(session.starts_at)}`, creatorPublication = () => {
    const verification = state.creator?.verification_status || "not_requested", approved = state.demo || verification === "verified", published = state.creator?.profile_status === "published";
    return { verification, approved, published, publicReady: approved && published };
  }, creatorReviewCopy = (verification) => ({
    not_requested: ["Draft", "Complete Creator setup to submit your identity for review."],
    submitted: ["Submitted", "Your profile is saved. Sessions stay private while verification is reviewed."],
    under_review: ["Under review", "Your profile and sessions stay private until verification is complete."],
    verified: ["Verified", "You control when your approved profile and sessions become public."],
    rejected: ["Needs attention", "Your drafts remain private. Contact support before submitting new public information."]
  })[verification] || ["Private", "Your Creator workspace is not public."], findSessionEntry = (sessionId) => {
    for (const entry of state.creators) {
      const session = entry.sessions.find((row) => row.id === sessionId);
      if (session) return { entry, session };
    }
    return null;
  }, addDemoNotification = (text, targetId = null) => {
    demoStore.notifications.unshift({ id: `demo-note-${++demoSequence}`, text, target_id: targetId, created_at: new Date(DEMO_EPOCH).toISOString() }), demoStore.notifications = demoStore.notifications.slice(0, 6);
  };
  function validateResolvedDestination(row) {
    if (!row?.destination_url || !row?.destination_label) return null;
    try {
      const url = new URL(row.destination_url);
      return url.protocol !== "https:" || url.username || url.password ? null : { state: "available", label: String(row.destination_label).slice(0, 120), url: url.href };
    } catch {
      return null;
    }
  }
  async function resolveHandoffDestination(session) {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  function uuid() {
    if (window.crypto?.randomUUID) return window.crypto.randomUUID();
    const bytes = new Uint8Array(16);
    return window.crypto.getRandomValues(bytes), bytes[6] = bytes[6] & 15 | 64, bytes[8] = bytes[8] & 63 | 128, [...bytes].map((byte, index) => `${[4, 6, 8, 10].includes(index) ? "-" : ""}${byte.toString(16).padStart(2, "0")}`).join("");
  }
  function cleanAttributionValue(value) {
    return String(value || "").trim().replace(/[^a-zA-Z0-9._ -]/g, "").slice(0, 80) || null;
  }
  function attributionStorageKey() {
    const accountId = String(state.profile?.id || "").trim();
    return ATTRIBUTION_KEY_PREFIX + ":" + (accountId || "anonymous");
  }
  function attributionContext() {
    const now = Date.now(), storageKey = attributionStorageKey();
    let saved = {};
    try {
      saved = JSON.parse(localStorage.getItem(storageKey) || "{}");
    } catch {
    }
    (!saved.journey_id || now - Number(saved.updated_at || 0) > ATTRIBUTION_MAX_AGE) && (saved = { journey_id: uuid() });
    const params = new URLSearchParams(window.location.search);
    saved.campaign_source = cleanAttributionValue(params.get("utm_source") || params.get("source")) || saved.campaign_source || null, saved.campaign_name = cleanAttributionValue(params.get("utm_campaign") || params.get("campaign")) || saved.campaign_name || null, saved.updated_at = now;
    try {
      localStorage.setItem(storageKey, JSON.stringify(saved));
    } catch {
    }
    return saved;
  }
  function updateAttribution(creatorId = null, sessionId = null) {
    const context = attributionContext();
    creatorId && (context.last_creator_id = creatorId), sessionId && (context.last_session_id = sessionId), context.updated_at = Date.now();
    try {
      localStorage.setItem(attributionStorageKey(), JSON.stringify(context));
    } catch {
    }
    return context;
  }
  async function trackProductEvent(eventName, options = {}) {
    PRODUCT_EVENTS.has(eventName) && demoStore.trace.push({ name: eventName, creator: options.creatorId || state.selectedCreator || "", session: options.sessionId || state.selectedSession || "", at: Date.now() }), demoStore.trace = demoStore.trace.slice(-20);
  }
  function injectStyles() {
    if (q("#lcProductStyles")) return;
    const style = document.createElement("style");
    style.id = "lcProductStyles", style.textContent = `
      #screen.lc-product-mode #homeView,#screen.lc-product-mode #accountPage,#screen.lc-product-mode>.bottom-nav,#screen.lc-product-mode #lcAuthShell{display:none!important}
      #lcProductShell{position:absolute;inset:0;z-index:74;overflow:auto;padding:calc(18px + env(safe-area-inset-top)) max(14px,env(safe-area-inset-left)) calc(72px + env(safe-area-inset-bottom)) max(14px,env(safe-area-inset-right));background:radial-gradient(circle at 85% 0,rgba(46,230,206,.13),transparent 35%),linear-gradient(180deg,#071012,#050708 72%);color:var(--text);scrollbar-width:none;-webkit-overflow-scrolling:touch}
      #lcProductShell[hidden]{display:none!important}.lc-product-stack{display:grid;gap:12px;width:100%;max-width:980px;margin:0 auto}.lc-product-top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:0 auto 12px;width:100%;max-width:980px}.lc-product-brand{display:flex;align-items:center;gap:10px;min-width:0}.lc-product-logo{flex:0 0 auto;width:38px;height:38px;border-radius:14px;background:linear-gradient(135deg,var(--teal),#a7fff4);color:#031412;display:grid;place-items:center;font-weight:950}.lc-product-brand strong{display:block;font-size:14px;line-height:1.15;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.lc-product-brand span,.lc-product-muted{display:block;color:var(--muted);font-size:12px;line-height:1.35}
      .lc-product-card{border:1px solid rgba(46,230,206,.15);border-radius:18px;background:rgba(8,13,16,.84);box-shadow:0 20px 52px rgba(0,0,0,.28);padding:14px;overflow:hidden}.lc-product-hero{padding:18px;background:linear-gradient(145deg,rgba(46,230,206,.14),rgba(255,255,255,.04));border-color:rgba(46,230,206,.32)}
      .lc-product-card h1,.lc-product-card h2,.lc-product-card h3{margin:0 0 8px;letter-spacing:0;text-wrap:balance}.lc-product-card h1{font-size:clamp(26px,7vw,36px);line-height:1.05}.lc-product-card h2{font-size:clamp(18px,4.5vw,22px);line-height:1.15}.lc-product-card h3{font-size:15px;line-height:1.2}.lc-product-card p{margin:0;color:var(--soft);font-size:14px;line-height:1.45;overflow-wrap:anywhere}.lc-product-label{display:inline-flex;align-items:center;gap:6px;border:1px solid rgba(46,230,206,.28);border-radius:999px;padding:6px 10px;color:#a7fff4;background:rgba(46,230,206,.1);font-size:10px;line-height:1;font-weight:900;text-transform:uppercase;margin-bottom:10px}.lc-product-section-head{display:flex;align-items:flex-end;justify-content:space-between;gap:10px;margin-bottom:6px}.lc-product-section-head span{color:var(--muted);font-size:11px;line-height:1.3}.lc-product-flow{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:6px}.lc-product-flow span{min-height:44px;display:grid;place-items:center;border:1px solid rgba(46,230,206,.14);border-radius:13px;background:rgba(255,255,255,.045);color:var(--soft);font-size:10px;line-height:1.1;font-weight:900;text-align:center;text-transform:uppercase;padding:6px}
      .lc-product-grid{display:grid;gap:10px}.lc-product-grid.two{grid-template-columns:repeat(2,minmax(0,1fr))}.lc-product-choice{min-height:98px;text-align:left;border:1px solid rgba(255,255,255,.1);border-radius:18px;background:rgba(255,255,255,.05);color:var(--text);padding:14px;cursor:pointer}.lc-product-choice b{display:block;font-size:15px;line-height:1.2;margin-bottom:7px}.lc-product-choice span{color:var(--muted);font-size:12px;line-height:1.35}.lc-product-choice.active{border-color:rgba(46,230,206,.58);background:rgba(46,230,206,.13)}
      .lc-product-form{display:grid;gap:10px}.lc-product-input,.lc-product-select,.lc-product-textarea{width:100%;min-height:46px;border:1px solid rgba(255,255,255,.11);border-radius:15px;background:rgba(255,255,255,.06);color:var(--text);padding:12px 13px;font:inherit;font-size:16px;line-height:1.35;outline:none}.lc-product-textarea{min-height:88px;resize:vertical}.lc-product-input:focus,.lc-product-select:focus,.lc-product-textarea:focus{border-color:rgba(46,230,206,.65);box-shadow:0 0 0 3px rgba(46,230,206,.1)}
      .lc-product-actions{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.lc-product-btn{display:inline-flex;align-items:center;justify-content:center;min-height:44px;border:0;border-radius:999px;background:linear-gradient(135deg,var(--teal),#a7fff4);color:#031412;padding:0 16px;font-size:12px;line-height:1.1;font-weight:900;cursor:pointer;text-align:center;white-space:normal}.lc-product-btn.secondary{border:1px solid rgba(255,255,255,.13);background:rgba(255,255,255,.06);color:var(--text)}.lc-product-btn:disabled{opacity:.55;cursor:not-allowed}.lc-product-chip{display:inline-flex;align-items:center;justify-content:center;min-height:36px;border:1px solid rgba(255,255,255,.11);border-radius:999px;background:rgba(255,255,255,.06);color:var(--soft);padding:0 11px;font-size:11px;line-height:1.1;font-weight:850;cursor:pointer;text-align:center}.lc-product-chip.active{border-color:rgba(46,230,206,.58);background:rgba(46,230,206,.14);color:#a7fff4}
      .lc-product-row{display:flex;align-items:center;gap:10px;padding:12px 0;border-top:1px solid rgba(255,255,255,.08)}.lc-product-row:first-child{border-top:0}.lc-product-row img{flex:0 0 auto;width:50px;height:50px;border-radius:16px;object-fit:cover}.lc-product-row-main{min-width:0;flex:1}.lc-product-row-main b{display:block;font-size:14px;line-height:1.25;overflow-wrap:anywhere}.lc-product-row-main span{display:block;color:var(--muted);font-size:12px;line-height:1.35;overflow-wrap:anywhere}.lc-product-status-dot{width:8px;height:8px;border-radius:50%;background:#778287;box-shadow:0 0 0 3px rgba(255,255,255,.04);flex:0 0 auto}.lc-product-status-dot.live{background:#5dffce;box-shadow:0 0 18px rgba(93,255,206,.45)}.lc-product-stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px}.lc-product-stat{padding:11px;border:1px solid rgba(255,255,255,.08);border-radius:14px;background:rgba(255,255,255,.04);min-width:0}.lc-product-stat b{display:block;font-size:17px;line-height:1.15;overflow-wrap:anywhere}.lc-product-stat span{display:block;color:var(--muted);font-size:10px;line-height:1.2;text-transform:uppercase;font-weight:850}
      .lc-product-row.unread{border-left:2px solid rgba(46,230,206,.72);padding-left:10px;background:linear-gradient(90deg,rgba(46,230,206,.055),transparent 48%)}
      .lc-product-tabs{position:relative;bottom:auto;z-index:3;display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;padding:7px;border:1px solid rgba(46,230,206,.16);border-radius:20px;background:rgba(5,8,9,.92);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);margin:12px auto 0;width:100%;max-width:980px}.lc-product-tabs button{min-height:44px;border:0;border-radius:14px;background:transparent;color:var(--muted);font-size:11px;line-height:1.05;font-weight:900;cursor:pointer}.lc-product-tabs button.active{background:rgba(46,230,206,.14);color:#a7fff4}.lc-product-note{display:block;margin-top:9px;color:var(--muted);font-size:11px;line-height:1.4;overflow-wrap:anywhere}.lc-product-empty{padding:24px 14px;text-align:center;color:var(--muted);font-size:14px;line-height:1.4}
      .lc-product-demo-banner{display:flex;align-items:center;justify-content:space-between;gap:8px;margin:0 auto 10px;padding:7px 8px;border:1px solid rgba(46,230,206,.16);border-radius:14px;background:rgba(255,255,255,.04);width:100%;max-width:980px}.lc-product-demo-banner strong{font-size:10px;line-height:1.1;color:#a7fff4;text-transform:uppercase;white-space:nowrap}.lc-product-demo-banner .lc-product-actions{margin-left:auto;justify-content:flex-end}
      .lc-product-connectivity{position:sticky;top:0;z-index:8;width:100%;max-width:980px;margin:0 auto 10px;padding:9px 12px;border:1px solid rgba(255,185,86,.24);border-radius:14px;background:rgba(45,29,8,.94);color:#ffe0ad;font-size:11px;line-height:1.35;text-align:center;box-shadow:0 14px 36px rgba(0,0,0,.22)}
      .lc-product-entry{min-height:100%;display:flex;flex-direction:column;gap:12px;width:100%;max-width:980px;margin:0 auto}.lc-product-entry-hero{padding:18px 4px 4px}.lc-product-entry-hero .lc-product-label{margin-bottom:12px}.lc-product-entry-hero h1{margin:0 0 8px;font-size:clamp(30px,8vw,46px);line-height:1.04;letter-spacing:0;color:var(--text);text-wrap:balance}.lc-product-entry-hero p{margin:0;color:var(--muted);font-size:13px;line-height:1.25;font-weight:850;text-transform:uppercase}.lc-product-entry-title{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:2px}.lc-product-entry-title strong{font-size:12px;line-height:1.2;text-transform:uppercase;color:var(--soft)}.lc-product-personas{display:grid;gap:10px}.lc-product-persona{position:relative;min-height:96px;border:1px solid rgba(255,255,255,.1);border-radius:18px;background:linear-gradient(145deg,rgba(255,255,255,.075),rgba(255,255,255,.035));color:var(--text);padding:14px;text-align:left;overflow:hidden;cursor:pointer}.lc-product-persona:after{content:"";position:absolute;right:-24px;top:-26px;width:80px;height:80px;border-radius:999px;background:rgba(46,230,206,.1);filter:blur(8px)}.lc-product-persona b{display:block;font-size:15px;line-height:1.2;margin-bottom:7px}.lc-product-persona span{display:block;max-width:32ch;color:var(--muted);font-size:12px;line-height:1.35}.lc-product-entry-auth{display:flex;gap:8px;margin-top:2px}.lc-product-entry-auth .lc-product-btn{flex:1}
      .lc-product-btn:focus-visible,.lc-product-chip:focus-visible,.lc-product-choice:focus-visible,.lc-product-persona:focus-visible,.lc-product-tabs button:focus-visible{outline:2px solid rgba(167,255,244,.9);outline-offset:2px}
      .lc-product-cinema{position:relative;min-height:520px;display:grid;align-content:end;overflow:hidden;border-radius:24px;border:1px solid rgba(167,255,244,.14);background:#020504;box-shadow:0 30px 90px rgba(0,0,0,.36),inset 0 0 0 1px rgba(255,255,255,.035)}.lc-product-cinema.compact{min-height:360px}.lc-product-cinema.copy-top{align-content:start}.lc-product-cinema img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;filter:saturate(1.05) contrast(1.04) brightness(.68)}.lc-product-cinema:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(2,5,4,.04),rgba(2,5,4,.12) 34%,rgba(2,5,4,.9)),linear-gradient(90deg,rgba(2,5,4,.58),transparent 54%);z-index:1}.lc-product-cinema.copy-top:after{background:linear-gradient(180deg,rgba(2,5,4,.88),rgba(2,5,4,.18) 46%,rgba(2,5,4,.86)),linear-gradient(90deg,rgba(2,5,4,.56),transparent 54%)}.lc-product-cinema-copy{position:relative;z-index:2;display:grid;justify-items:start;gap:10px;padding:18px}.lc-product-cinema-copy h1{margin:0;max-width:12ch;font-size:clamp(36px,9vw,58px);line-height:.92;font-weight:870;color:#f7fffb}.lc-product-cinema-copy p{max-width:31ch;color:#f7fffb;font-size:14px}.lc-product-cinema .lc-product-actions{position:relative;z-index:2}.lc-product-media-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.lc-product-media-tile{position:relative;min-height:176px;overflow:hidden;border-radius:18px;border:1px solid rgba(255,255,255,.08);background:#07100e}.lc-product-media-tile.large{grid-column:1/-1;min-height:260px}.lc-product-media-tile img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;filter:saturate(1.04) brightness(.72)}.lc-product-media-tile:after{content:"";position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.04),rgba(2,5,4,.86));z-index:1}.lc-product-media-copy{position:absolute;left:12px;right:12px;bottom:12px;z-index:2;display:grid;gap:7px;justify-items:start}.lc-product-card{border-color:rgba(167,255,244,.12);background:rgba(5,9,8,.72);box-shadow:0 24px 70px rgba(0,0,0,.26);backdrop-filter:blur(18px)}.lc-product-hero{background:linear-gradient(145deg,rgba(31,216,196,.1),rgba(255,255,255,.035));border-color:rgba(167,255,244,.2)}.lc-product-tabs{border-color:rgba(167,255,244,.13);background:rgba(2,6,5,.9)}@media(prefers-reduced-motion:reduce){.screen,.lc-product-cinema,.lc-product-card{animation:none!important;transition:none!important}}@media(max-width:430px){.lc-product-cinema{min-height:calc(var(--app-height) - 168px)}.lc-product-cinema.compact{min-height:390px}.lc-product-cinema-copy{padding:16px}.lc-product-cinema-copy h1{font-size:40px}.lc-product-media-grid{grid-template-columns:1fr}.lc-product-media-tile.large{min-height:260px}}
      @media(min-width:720px){#lcProductShell{padding:24px 18px 104px}.lc-product-grid.desktop-two{grid-template-columns:repeat(2,minmax(0,1fr))}.lc-product-personas{grid-template-columns:repeat(2,minmax(0,1fr))}.lc-product-card{padding:16px}.lc-product-hero{padding:20px}.lc-product-entry{max-width:min(920px,92vw)}}@media(min-width:1180px){#lcProductShell{padding:30px 28px 112px}.lc-product-stack,.lc-product-top,.lc-product-tabs,.lc-product-demo-banner{max-width:1040px}.lc-product-entry{max-width:960px}.lc-product-persona{min-height:112px;padding:18px}}@media(max-width:430px){#lcProductShell{padding-top:calc(12px + env(safe-area-inset-top));padding-left:12px;padding-right:12px;padding-bottom:calc(48px + env(safe-area-inset-bottom))}.lc-product-top{margin-bottom:8px}.lc-product-logo{width:34px;height:34px;border-radius:12px}.lc-product-brand span{display:none}.lc-product-brand strong{font-size:13px}.lc-product-top>.lc-product-chip{min-height:32px;padding:0 10px}.lc-product-cinema.compact{min-height:350px}.lc-product-card{padding:13px;border-radius:17px}.lc-product-card h1{font-size:26px}.lc-product-grid.two{grid-template-columns:1fr}.lc-product-flow{grid-template-columns:repeat(3,minmax(0,1fr))}.lc-product-row{align-items:flex-start}.lc-product-row .lc-product-chip{margin-left:auto}.lc-product-actions{gap:7px}.lc-product-btn{min-height:44px;padding:0 13px;font-size:11px}.lc-product-chip{min-height:35px;font-size:10.5px}.lc-product-entry-hero h1{font-size:30px}.lc-product-persona{min-height:92px;padding:13px}.lc-product-demo-banner{align-items:center;flex-direction:row;padding:5px 6px;gap:5px;min-height:42px}.lc-product-demo-banner strong{font-size:9px;letter-spacing:.08em;flex:0 0 auto}.lc-product-demo-banner .lc-product-actions{width:auto;min-width:0;flex:1;margin-left:0;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:4px}.lc-product-demo-banner .lc-product-chip{min-width:0;min-height:31px;padding:0 6px;font-size:9px;line-height:1;white-space:nowrap}.lc-product-entry-auth{position:sticky;bottom:8px;z-index:3;padding:7px;border:1px solid rgba(46,230,206,.16);border-radius:20px;background:rgba(5,8,9,.92);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px)}}
      @media(max-width:430px){.lc-product-demo-banner{align-items:stretch;flex-direction:column;padding:10px;gap:8px;min-height:auto}.lc-product-demo-banner strong{font-size:8px;line-height:1.45;white-space:normal}.lc-product-demo-banner .lc-product-actions{width:100%;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px}.lc-product-demo-banner .lc-product-chip{min-width:0}}
    `, document.head.appendChild(style);
  }
  function injectInvestorStyles() {
    if (q("#lcInvestorStyles")) return;
    const style = document.createElement("style");
    style.id = "lcInvestorStyles", style.textContent = `
      #screen.lc-product-mode:has(#lcProductShell[data-lc-investor=true])>#appTop{display:none!important}
      #lcProductShell[data-lc-investor=true] .lc-v4-feed-caption time,#lcProductShell[data-lc-investor=true] .lc-v4-feed-comment>span{color:#b6cfc7;font-size:12px}
      #lcProductShell[data-lc-investor=true] .lc-v4-home-switch button:not(.active){color:#b6cfc7}
      #lcProductShell[data-lc-investor=true] :is(button,input,select,textarea,a):focus-visible{outline:3px solid #a7fff4;outline-offset:3px}
      .lc-investor-guide{max-width:980px;margin:0 auto 18px;padding:18px;border:1px solid #37665c;border-radius:20px;background:linear-gradient(135deg,#102924,#071512);color:#eefcf5}
      .lc-investor-guide h2{font-size:22px;margin:8px 0}.lc-investor-guide p{max-width:760px;line-height:1.55;color:#b6cfc7;margin:8px 0 14px}
      .lc-investor-steps{display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px}.lc-investor-steps button{min-height:36px;border:1px solid #45665c;border-radius:12px;background:transparent;color:#cfebe1;padding:7px 12px}.lc-investor-steps button[aria-current=step]{background:#cbf5df;color:#082419}
      .lc-demo-games{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.lc-demo-games button{min-height:95px;text-align:left;border:1px solid #355c50;border-radius:18px;background:linear-gradient(130deg,#142b22,#08140e);color:#eafff3;padding:18px}.lc-demo-games b{display:block;font-size:21px}.lc-demo-games span{display:block;font-size:12px;color:#b9d3c6;margin-top:7px}
      .lc-demo-table{border:1px solid #597b5c;border-radius:24px;padding:22px;background:radial-gradient(ellipse at top,#214b37,#07150f);color:#effaef}.lc-demo-table h2{margin:8px 0}.lc-demo-hands{display:grid;grid-template-columns:1fr 1fr;gap:15px;margin:20px 0}.lc-demo-hand{padding:14px;border:1px solid #688c73;border-radius:16px}.lc-demo-hand strong{display:block;margin-bottom:12px}.lc-demo-card{display:inline-flex;align-items:center;justify-content:center;width:48px;height:65px;margin:0 5px 7px 0;background:#f7f2e7;color:#14251c;border-radius:7px;font-size:21px;font-family:Georgia,serif;box-shadow:0 5px 18px #0004}.lc-demo-chat ul{list-style:none;padding:0}.lc-demo-chat li{padding:10px 0;border-bottom:1px solid #304a40;overflow-wrap:anywhere}.lc-demo-chat form{display:flex;gap:8px}.lc-demo-chat input{flex:1;min-width:0}
      .lc-demo-room .lc-v4-live-actions{position:static}.lc-demo-room .lc-v4-live-stage{min-height:360px}#lcProductShell img{max-width:100%}.lc-product-demo-banner{max-width:980px}.lc-investor-guide .lc-product-actions{flex-wrap:wrap}.lc-demo-table small{display:block;color:#c0d6c8;line-height:1.5}
      #lcProductShell[data-lc-investor=true]:not([data-lc-business-view]) .lc-product-demo-banner{max-width:1100px!important;margin-inline:auto;width:calc(100% - 20px);box-sizing:border-box}
      #lcProductShell[data-lc-investor=true]:not([data-lc-business-view]) .lc-investor-guide{max-width:760px;box-sizing:border-box;width:calc(100% - 20px)}
      #lcProductShell[data-lc-investor=true] .lc-v4-explore-hero{padding:22px;align-items:center;gap:18px}
      #lcProductShell[data-lc-investor=true] .lc-v4-explore-hero h1{font-size:32px;max-width:20ch;line-height:1.12}
      #lcProductShell[data-lc-investor=true] .lc-v4-explore-state{max-width:160px;flex-shrink:0}
      #lcProductShell[data-lc-investor=true] .lc-v4-explore-state span{font-size:12px;letter-spacing:0;line-height:1.4;color:#b6cfc7}
      #lcProductShell[data-lc-investor=true] .lc-v4-feed-media{aspect-ratio:16/9}#lcProductShell[data-lc-investor=true] .lc-v4-feed-media img{object-position:center 20%}
      #lcProductShell[data-lc-investor=true] .lc-v4-creator-hero{min-height:380px}
      #lcProductShell[data-lc-investor=true] .lc-v4-live-orb>span{border-color:#68c8b7}
      #lcProductShell[data-lc-investor=true] .lc-v4-live-orb i{font-size:10px;letter-spacing:0;background:#153b31;color:#d7fff0;padding:4px 6px}
      #lcProductShell[data-lc-investor=true] .lc-v4-creator-hero>img,#lcProductShell[data-lc-investor=true] .lc-v4-live-stage>img{object-position:center 30%}
      #lcProductShell[data-lc-investor=true] .lc-v4-feed-post>.lc-product-note{padding:0 16px 12px;font-size:14px;color:#d6e6df;line-height:1.5;overflow-wrap:anywhere}
      #lcProductShell[data-lc-investor=true] .lc-v4-creator-content-grid article{min-height:0;border:1px solid #304a40}
      #lcProductShell[data-lc-investor=true] .lc-v4-creator-content-grid article>img{position:static;display:block;height:180px;opacity:1;object-position:center 20%}
      #lcProductShell[data-lc-investor=true] .lc-v4-creator-content-grid article>div{position:static;padding:16px;background:#0c1b17}
      #lcProductShell[data-lc-investor=true] .lc-v4-creator-content-grid p{overflow-wrap:anywhere;color:#d6e6df;font-size:14px}
      #lcProductShell[data-lc-investor=true] .lc-v4-creator-content-grid form{display:grid;gap:8px;margin-top:12px}#lcProductShell[data-lc-investor=true] .lc-v4-creator-content-grid label{font-size:13px;color:#c6dfd3}
      @media(max-width:430px){#lcProductShell[data-lc-investor=true] .lc-v4-feed-comment{flex-wrap:wrap}#lcProductShell[data-lc-investor=true] .lc-v4-feed-comment>span{flex-basis:100%}#lcProductShell[data-lc-investor=true] .lc-investor-guide p{font-size:14px;line-height:1.4;margin:6px 0 10px}#lcProductShell[data-lc-investor=true] .lc-investor-guide .lc-product-actions{gap:6px}#lcProductShell[data-lc-investor=true] .lc-investor-guide .lc-product-actions button{min-height:36px;padding:8px 10px;font-size:11px}#lcProductShell[data-lc-investor=true] .lc-v4-feed-media{aspect-ratio:4/3}#lcProductShell[data-lc-investor=true] .lc-v4-creator-hero{min-height:320px}#lcProductShell[data-lc-investor=true] .lc-v4-explore-hero h1{font-size:27px}#lcProductShell[data-lc-investor=true] .lc-v4-explore-state{max-width:none;padding:10px 14px;display:flex;align-items:center;gap:12px}#lcProductShell[data-lc-investor=true] .lc-v4-explore-state b{font-size:22px}#lcProductShell[data-lc-investor=true] .lc-investor-guide{padding:14px}.lc-investor-steps button{padding:7px 9px;font-size:12px}.lc-investor-guide h2{font-size:20px}.lc-demo-games{gap:8px}.lc-demo-games button{padding:13px}.lc-demo-hands{gap:8px}.lc-demo-hand{padding:10px}.lc-demo-card{width:35px;height:50px;font-size:17px}.lc-demo-table{padding:15px}.lc-demo-chat form{flex-wrap:wrap}}
    `, document.head.appendChild(style);
  }
  function investorGuide() {
    if (!investorMode || !state.demo || tourStep < 0) return "";
    const [title, body, action] = tourScenarios[tourStep];
    return `<section class="lc-investor-guide" aria-label="Investor walkthrough"><nav class="lc-investor-steps" aria-label="Guided scenarios">${tourScenarios.map((step, index) => `<button type="button" data-lc-tour-step="${index}" aria-label="${index + 1} · ${safe(step[0])}" ${tourStep === index ? 'aria-current="step"' : ""}>${index + 1} · ${["Discover", "Social", "Business"][index]}</button>`).join("")}</nav><h2>${safe(title)}</h2><p>${safe(body)}</p><div class="lc-product-actions"><button class="lc-product-btn" type="button" data-lc-tour-action>${safe(action)}</button><button class="lc-product-chip" type="button" data-lc-tour-next>${tourStep === 2 ? "Finish walkthrough" : "Next scenario"}</button><button class="lc-product-chip" type="button" data-lc-tour-skip>Skip walkthrough</button></div></section>`;
  }
  function renderDemoTable(session) {
    if (!state.demo || !["Blackjack", "Baccarat"].includes(session.game)) return "";
    const round = (demoStore.roomRounds.get(session.id) || 0) % 3, blackjack = session.game === "Blackjack", hands = blackjack ? [["A♠", "K♦", "10♣", "7♥"], ["10♥", "8♣", "Q♠", "9♦"], ["9♠", "7♥", "10♦", "6♣"]] : [["4♠", "3♥", "5♣", "2♦"], ["A♥", "6♣", "4♠", "5♦"], ["2♠", "3♥", "A♦", "7♣"]], labels = blackjack ? ["Player hand", "Dealer hand"] : ["Player side", "Banker side"], cards = hands[round], messages = demoStore.roomMessages.get(session.id) || [];
    return `<section class="lc-demo-table" aria-label="Scripted ${safe(session.game)} table"><span class="lc-product-label">SCRIPTED TABLE PREVIEW · NO WAGERS</span><h2>${safe(session.game)} with ${safe(profileName(demoProfile(session.creator_id)))}</h2><small>Example round ${round + 1} of 3. Fixed cards demonstrate the room presentation, not a playable casino engine or broadcast.</small><div class="lc-demo-hands">${labels.map((label, index) => `<div class="lc-demo-hand"><strong>${label}</strong>${cards.slice(index * 2, index * 2 + 2).map((card) => `<span class="lc-demo-card">${safe(card)}</span>`).join("")}</div>`).join("")}</div><button class="lc-product-btn secondary" type="button" data-lc-demo-round="${safe(session.id)}">Show next demo round</button></section><section class="lc-product-card lc-demo-chat"><h2>Room conversation</h2><p>Only your local demo messages appear here. There are no connected players.</p><button class="lc-product-chip" type="button" data-lc-demo-react="${safe(session.id)}" aria-label="React to this room" aria-pressed="${demoStore.roomReactions.has(session.id)}">${demoStore.roomReactions.has(session.id) ? "♥ Reaction added" : "♡ React to this room"}</button><ul aria-live="polite">${messages.length ? messages.map((message) => `<li><b>You</b> · <span data-lc-user-content>${safe(message)}</span></li>`).join("") : "<li>No messages yet. Start the conversation.</li>"}</ul><form data-lc-form="room-chat" data-session-id="${safe(session.id)}"><input class="lc-product-input" name="body" maxlength="240" required aria-label="Message the demo room" placeholder="Write a message"><button class="lc-product-btn" type="submit">Send</button></form></section>`;
  }
  function refreshDemoRoom(id) {
    const root = q("#lcProductShell"), found = findSessionEntry(id);
    if (!root || !found || !root.querySelector(".lc-demo-table")) return renderLive(id);
    retainInvestorFocus(root);
    const scrollTop = root.scrollTop, content = document.createElement("div");
    content.innerHTML = renderDemoTable(found.session);
    for (const selector of [".lc-demo-table", ".lc-demo-chat"]) root.querySelector(selector)?.replaceWith(content.querySelector(selector));
    root.scrollTop = scrollTop;
  }
  function retainInvestorFocus(root) {
    const active = document.activeElement;
    if (!investorMode || !state.demo || !root?.contains(active) || !active.matches("button,input,select,textarea,a")) return;
    const attributes = Array.from(active.attributes).filter((attribute) => attribute.name.startsWith("data-lc-") || ["id", "name", "type"].includes(attribute.name)), form = active.closest("form"), formKey = form ? JSON.stringify(form.dataset) : null, text = active.tagName === "BUTTON" ? active.textContent : null, scroll = root.scrollTop;
    window.requestAnimationFrame(() => {
      const replacement = Array.from(root.querySelectorAll("button,input,select,textarea,a")).find((control) => control.tagName === active.tagName && attributes.every((attribute) => control.getAttribute(attribute.name) === attribute.value) && (formKey === null || JSON.stringify(control.closest("form")?.dataset) === formKey) && (attributes.some((attribute) => attribute.name.startsWith("data-lc-")) || text === null || control.textContent === text)), destination = replacement || root.querySelector("h1") || root.querySelector("h2") || root;
      replacement && (root.scrollTop = scroll), replacement || destination.setAttribute("tabindex", "-1"), destination.focus({ preventScroll: !0 });
    });
  }
  function shell() {
    injectStyles(), injectInvestorStyles();
    let node = q("#lcProductShell");
    return node || (node = document.createElement("section"), node.id = "lcProductShell", node.setAttribute("aria-label", "LC App product experience"), q("#screen")?.appendChild(node)), retainInvestorFocus(node), q("#screen")?.classList.add("lc-product-mode"), state.current?.persona !== "industry" && delete node.dataset.lcBusinessView, node.dataset.lcInvestor = investorMode ? "true" : "false", node.hidden = !1, node.scrollTop = 0, window.scrollTo(0, 0), node;
  }
  function hide() {
    q("#lcProductShell")?.setAttribute("hidden", ""), q("#screen")?.classList.remove("lc-product-mode");
  }
  function setBusy(button, busy = !0) {
    state.busy = busy, button && (button.disabled = busy);
    const root = q("#lcProductShell");
    root && (busy ? root.setAttribute("aria-busy", "true") : root.removeAttribute("aria-busy"));
  }
  function values(form, name) {
    return qa(`[name="${name}"]:checked`, form).map((input) => input.value);
  }
  async function loadState() {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  async function loadPilotBriefs() {
    state.pilotBriefs = [...demoStore.pilotBriefs];
  }
  async function loadReturnSignals() {
  }
  async function loadOwnCreatorData() {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  async function loadCreators() {
    setDemoCreators();
  }
  async function setCurrentPersona(persona, industrySubtype = null) {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  async function completeCurrentPersona() {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  function top(title = "LC App", subtitle = "Live Casino. Social Experience.") {
    const persona = state.profile?.role === "admin" || state.profile?.role === "moderator" ? "admin" : state.current?.persona === "industry" ? state.industry?.subtype || state.current?.industry_subtype || "operator" : state.current?.persona || "persona", accountTarget = state.current?.persona === "industry" ? 'data-lc-business-view="settings"' : 'data-lc-product="profile"';
    return `
      <div class="lc-product-top">
        <div class="lc-product-brand"><span class="lc-product-logo">LC</span><div><strong>${safe(title)}</strong><span>${safe(subtitle)}</span></div></div>
        <button class="lc-product-chip" type="button" ${accountTarget}>${safe(persona)}</button>
      </div>
      ${state.demo ? `<div class="lc-product-demo-banner"><strong>DEMO · LOCAL DATA</strong><div class="lc-product-actions"><details class="lc-demo-controls" ${window.innerWidth >= 1e3 ? "open" : ""}><summary>Switch role · ${safe(state.demoPersona || "player")}</summary><div>${["player", "creator", "operator", "provider"].map((role) => `<button class="lc-product-chip" type="button" data-lc-demo-persona="${role}" aria-pressed="${state.demoPersona === role}">${role[0].toUpperCase() + role.slice(1)}</button>`).join("")}<button class="lc-product-chip" type="button" data-lc-demo-reset>Reset</button><button class="lc-product-chip" type="button" data-lc-demo-exit>Roles</button></div></details><a class="lc-product-chip" href="../?lang=${document.documentElement.lang}#contact">Request Pilot</a>${investorMode ? '<button class="lc-product-chip" type="button" data-lc-tour-restart>Guide</button>' : ""}</div></div>` : ""}
      ${investorGuide()}
    `;
  }
  function tabs(active) {
    return (state.current?.persona || "start") === "industry" ? "" : `<div class="lc-product-tabs" aria-label="Primary navigation">${[["home", "Home"], ["explore", "Explore"], ["create", "Create"], ["activity", "Activity"], ["profile", "Profile"]].map(([id, label]) => `<button class="${active === id ? "active" : ""}" type="button" data-lc-product="${id}"><span class="lc-v4-social-icon" aria-hidden="true">${{ home: "⌂", explore: "◎", create: "+", activity: "♡", profile: "◉" }[id]}</span><span>${label}</span></button>`).join("")}</div>`;
  }
  function checks(name, list, selected = []) {
    const set = new Set(selected || []);
    return `<div class="lc-product-actions">${list.map((item) => `<label class="lc-product-chip ${set.has(item) ? "active" : ""}"><input style="display:none" type="checkbox" name="${safe(name)}" value="${safe(item)}" ${set.has(item) ? "checked" : ""}>${safe(item)}</label>`).join("")}</div>`;
  }
  const visualImage = (profile) => visualMedia[profile?.id] || visualMedia.fallback, visualHero = (label, title, body, image, actions = "", mode = "") => `<section class="lc-product-cinema ${mode}"><img src="${safe(image || visualMedia.fallback)}" alt=""><div class="lc-product-cinema-copy"><span class="lc-product-label">${safe(label)}</span><h1>${safe(title)}</h1><p>${safe(body)}</p>${actions ? `<div class="lc-product-actions">${actions}</div>` : ""}</div></section>`, visualTile = (image, label, title, body, large = !1) => `<article class="lc-product-media-tile ${large ? "large" : ""}"><img src="${safe(image || visualMedia.fallback)}" alt=""><div class="lc-product-media-copy"><span class="lc-product-label">${safe(label)}</span><h3>${safe(title)}</h3><p>${safe(body)}</p></div></article>`;
  function renderLoading() {
    const root = shell();
    root.setAttribute("aria-busy", "true"), root.innerHTML = `${top()}<section class="lc-product-card lc-product-empty lc-product-loading" role="status" aria-live="polite"><span class="lc-product-spinner" aria-hidden="true"></span><h2>Loading your LC experience</h2><p>Restoring your profile, social signals and saved context.</p></section>`, syncConnectivity();
  }
  function syncConnectivity() {
    const root = q("#lcProductShell");
    if (!root) return;
    const existing = q("#lcProductConnectivity", root);
    if (navigator.onLine) {
      existing && !existing.classList.contains("is-online") && (existing.classList.add("is-online"), existing.textContent = "Back online. Refreshing your LC context.", window.setTimeout(() => existing.isConnected && existing.remove(), 2200));
      return;
    }
    if (existing) {
      existing.classList.remove("is-online"), existing.textContent = "You are offline. Saved screens remain available; account changes need a connection.";
      return;
    }
    const banner = document.createElement("div");
    banner.id = "lcProductConnectivity", banner.className = "lc-product-connectivity", banner.setAttribute("role", "status"), banner.setAttribute("aria-live", "polite"), banner.textContent = "You are offline. Saved screens remain available; account changes need a connection.", root.prepend(banner);
  }
  function renderLoadError(error) {
    state.loadError = error || new Error("load");
    const root = shell();
    root.removeAttribute("aria-busy"), root.innerHTML = `${top()}<section class="lc-product-card lc-product-empty lc-product-load-error" role="alert" aria-live="assertive"><h2>We could not load LC App</h2><p id="lcProductLoadError">${safe(err(error))}</p><div class="lc-product-actions"><button class="lc-product-btn" type="button" data-lc-retry aria-describedby="lcProductLoadError">TRY AGAIN</button></div><span class="lc-product-note">Your account data has not been changed.</span></section>`, syncConnectivity();
  }
  function renderAccountDenied() {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  async function retryLoad(button = null, silent = !1) {
    if (!(state.retrying || !state.client || !state.profile)) {
      state.retrying = !0, button && (button.disabled = !0), renderLoading();
      try {
        await loadState(), state.loadError = null, renderProductTarget(productParts()), q("#lcProductShell")?.removeAttribute("aria-busy"), syncConnectivity(), silent || toast("Product reconnected");
      } catch (error) {
        renderLoadError(error);
      } finally {
        state.retrying = !1, button?.isConnected && (button.disabled = !1);
      }
    }
  }
  function demoProfile(id) {
    return demoProfiles.find((profile) => profile.id === id) || demoProfiles[0];
  }
  function setDemoCreators() {
    state.creators = demoCreators.map((creator) => ({
      creator,
      profile: demoProfile(creator.user_id),
      sessions: [...demoSessions, ...demoStore.sessions].map((session) => ({ ...session, ...demoStore.sessionOverrides.get(session.id) || {} })).filter((session) => session.creator_id === creator.user_id),
      posts: [...demoStore.posts, ...demoPosts].filter((post) => post.author_id === creator.user_id)
    }));
  }
  function refreshDemoData() {
    setDemoCreators(), state.follows = new Set(demoStore.follows), state.creatorLiveAlerts = new Map(demoStore.creatorLiveAlerts), state.reminders = new Set(demoStore.reminders), state.accessRequests = [...demoStore.requests].map((industry_subtype) => ({ industry_subtype, status: "submitted", created_at: (/* @__PURE__ */ new Date()).toISOString() })), state.pilotBriefs = [...demoStore.pilotBriefs], state.notifications = demoStore.notifications, state.sessions = [...demoSessions, ...demoStore.sessions].map((session) => ({ ...session, ...demoStore.sessionOverrides.get(session.id) || {} })).filter((session) => session.creator_id === state.profile?.id), state.posts = [...demoStore.posts, ...demoPosts].filter((post) => post.author_id === state.profile?.id);
  }
  function setupDemo(persona, shouldReset = !1) {
    shouldReset && (resetDemoStore(), state.search = "", state.selectedCreator = null, state.selectedSession = null), shouldReset && persona === "player" && (demoStore.follows.add("demo-sofia"), demoStore.creatorLiveAlerts.set("demo-sofia", !0), demoStore.reminders.add("demo-session-mia"), addDemoNotification("Sofia's illustrative session preview is ready. No live broadcast or operator connection is implied.", "demo-session-sofia")), shouldReset && persona === "creator" && addDemoNotification("You followed Sofia and saved the next preview session.", "demo-sofia");
    const industrySubtype = ["provider", "operator", "admin"].includes(persona) ? persona : null, currentPersona = industrySubtype ? "industry" : persona;
    state.client = null, state.demo = !0, state.demoPersona = persona, state.discoveryFilter = "for_you", state.socialView = persona === "creator" ? "create" : "home", state.creatorStudioView = "overview", state.businessView = "overview", state.handoffDestinations.clear(), state.current = { id: `demo-${persona}`, persona: currentPersona, industry_subtype: industrySubtype, onboarding_status: "completed", is_current: !0 }, state.profile = persona === "creator" ? demoProfile("demo-sofia") : { id: "demo-reviewer", username: "demo_reviewer", display_name: "Demo Reviewer", avatar_url: "app-icon-512.png", role: persona === "admin" ? "admin" : "user", account_status: "active", onboarding_completed: !0 }, state.player = currentPersona === "player" ? { user_id: state.profile.id, favorite_games: ["Blackjack", "Roulette"], preferred_languages: ["English"], onboarding_completed: !0 } : null, state.creator = currentPersona === "creator" ? { ...demoCreators[0], onboarding_completed: !0 } : null, state.industry = currentPersona === "industry" ? { user_id: state.profile.id, subtype: industrySubtype, company_name: "Demo Company", job_title: "Industry reviewer", work_email: "demo@example.com", interests, access_status: "not_requested", onboarding_completed: !0 } : null, refreshDemoData();
  }
  function enterDemo(persona) {
    if (investorMode && (tourStep = -1), window.LC_APP_MODE === "public_demo" && !["player", "creator", "operator", "provider"].includes(persona)) return renderMissing("Role unavailable", "This role is not part of the public demo.", "Back to Discover");
    setupDemo(persona, !state.demo), !setProductHash(["demo", persona]) && routeHome();
  }
  function renderDemoEntry() {
    shell().innerHTML = `${top("LC", "Choose the product you want to explore")}
      <div class="lc-product-entry lc-v4-entry">
        <section class="lc-v4-entry-hero"><span class="lc-v3-kicker">LC APP · INTERACTIVE DEMO</span><h1>Discover the People<br>Behind the Tables.</h1><p>Explore creators, follow your favorites, discover upcoming sessions, and continue to participating licensed operators when available.</p></section>
        <section class="lc-v4-entry-family lc-v4-entry-social"><div><span>PLAYER EXPERIENCE</span><h2>Follow the person.<br>Return for the next session.</h2><p>Discover creators, view illustrative profiles and schedules, and preview the licensed-operator handoff journey.</p></div><div class="lc-v4-entry-actions"><button class="lc-product-btn" type="button" data-lc-demo-persona="player">ENTER AS PLAYER</button><button class="lc-product-btn secondary" type="button" data-lc-demo-persona="creator">ENTER AS CREATOR</button></div></section>
        <section class="lc-v4-entry-family lc-v4-entry-business"><div><span>BUSINESS BACK OFFICE</span><h2>Manage the creator-led path to Live.</h2><p>Configuration, creator operations, campaigns, integrations, safety and observed evidence. No invented performance claims.</p></div><div class="lc-v4-entry-actions"><button class="lc-product-btn" type="button" data-lc-demo-persona="operator">OPERATOR CONSOLE</button><button class="lc-product-btn secondary" type="button" data-lc-demo-persona="provider">PROVIDER CONSOLE</button></div></section>
        <section class="lc-v4-boundary-note"><b>LC does not operate the casino.</b><span>Gameplay, wallet, deposits, withdrawals, KYC/AML, wagering, settlement and responsible-gaming operations stay with licensed operator/provider infrastructure.</span></section>
      </div>`;
  }
  function renderPersonaChoice() {
    shell().innerHTML = `${top("How will you use LC App?", "Choose a product experience. This is not a security role.")}
      <div class="lc-product-stack">
        <section class="lc-product-card lc-product-hero"><span class="lc-product-label">Product persona</span><h1>Start with your role in Live Casino.</h1><p>You can add another experience later without changing account permissions.</p></section>
        <section class="lc-product-grid">
          <button class="lc-product-choice" type="button" data-lc-persona="player"><b>Player</b><span>Discover creators, follow sessions and return to live tables.</span></button>
          <button class="lc-product-choice" type="button" data-lc-persona="creator"><b>Creator / Dealer</b><span>Build a public profile, post updates and publish session schedules.</span></button>
          <button class="lc-product-choice" type="button" data-lc-persona="industry"><b>Industry</b><span>Evaluate the operator/provider fit and request access.</span></button>
        </section>
      </div>`;
  }
  function renderIndustrySubtype() {
    shell().innerHTML = `${top("Industry experience", "Select company context.")}
      <div class="lc-product-stack">
        <section class="lc-product-card"><h2>What type of company are you evaluating from?</h2><p>This is an unverified product context, not account approval.</p></section>
        <section class="lc-product-grid">
          ${["operator", "provider", "aggregator", "other"].map((item) => `<button class="lc-product-choice" type="button" data-lc-industry="${item}"><b>${safe(item.replace(/^./, (m) => m.toUpperCase()))}</b><span>${item === "provider" ? "Game distribution through creators and live tables." : item === "operator" ? "Player discovery, follow and handoff journey." : "Integration and distribution evaluation."}</span></button>`).join("")}
        </section>
      </div>`;
  }
  function renderPlayerOnboarding() {
    const selectedGames = state.player?.favorite_games || [], selectedLanguages = state.player?.preferred_languages || [];
    shell().innerHTML = `${top("Welcome", "Build your creator-first Live Casino feed")}
      <form class="lc-product-stack lc-product-form lc-v3-onboarding" data-lc-form="player">
        <section class="lc-v3-onboarding-hero">
<span class="lc-v3-kicker">PLAYER SETUP · 1 MINUTE</span>
<h1>Who do you want to come back for?</h1>
<p>LC uses your game and language preferences to rank creators. You can change these later.</p>
<div class="lc-v3-progress"><span></span><span></span><span></span></div>
        </section>
        <section class="lc-product-card lc-v3-preference-card">
<div class="lc-product-section-head"><div><span class="lc-v3-step">01</span><h2>Games you actually play</h2></div><span>${selectedGames.length ? `${selectedGames.length} selected` : "Choose at least one"}</span></div>
<p>Used only for creator discovery ranking. It does not change gameplay or casino access.</p>
<div class="lc-v3-choice-wrap">${checks("games", games, selectedGames)}</div>
        </section>
        <section class="lc-product-card lc-v3-preference-card">
<div class="lc-product-section-head"><div><span class="lc-v3-step">02</span><h2>Languages you prefer</h2></div><span>${selectedLanguages.length ? `${selectedLanguages.length} selected` : "Choose at least one"}</span></div>
<p>Helps surface creators you can comfortably follow across sessions.</p>
<div class="lc-v3-choice-wrap">${checks("languages", languages, selectedLanguages)}</div>
        </section>
        <section class="lc-v3-value-strip"><div><b>Discover people</b><span>Not anonymous tables</span></div><div><b>Follow creators</b><span>Keep the relationship</span></div><div><b>Return when Live</b><span>Build continuity</span></div></section>
        <button class="lc-product-btn lc-v3-primary-wide" type="submit">BUILD MY DISCOVER FEED</button>
        <span class="lc-product-note lc-v3-center-note">No wallet, wagering, KYC or deposits are handled by LC App.</span>
      </form>`;
  }
  function renderCreatorOnboarding() {
    const c = state.creator || {};
    shell().innerHTML = `${top("Creator setup", "Dealer identity becomes followable.")}
      <form class="lc-product-stack lc-product-form" data-lc-form="creator">
        <section class="lc-product-card lc-product-hero"><span class="lc-product-label">Creator / Dealer</span><h1>From dealer to creator.</h1><p>Create a public profile, publish sessions and let players follow your live presence.</p></section>
        <section class="lc-product-card"><h2>Identity</h2><input class="lc-product-input" name="headline" maxlength="120" placeholder="Headline" value="${safe(c.headline || "Live Casino creator")}"><textarea class="lc-product-textarea" name="bio" maxlength="280" placeholder="Short bio">${safe(state.profile.bio || "")}</textarea></section>
        <section class="lc-product-card"><h2>Games</h2>${checks("games", games, c.games)}</section>
        <section class="lc-product-card"><h2>Languages</h2>${checks("languages", languages, c.languages || state.profile.languages)}</section>
        <section class="lc-product-card"><h2>Affiliation</h2><select class="lc-product-select" name="affiliation_type"><option value="unlisted">Not listed</option><option value="independent">Independent</option><option value="operator">Operator</option><option value="studio">Studio</option><option value="provider">Provider</option></select><input class="lc-product-input" name="affiliation_name" maxlength="120" placeholder="Company, studio or provider (optional)" value="${safe(c.affiliation_name || "")}"><span class="lc-product-note">Affiliation is user claimed and unverified until reviewed.</span></section>
        <section class="lc-product-card"><h2>Preview</h2><div class="lc-product-row"><img src="${safe(avatar(state.profile))}" alt=""><div class="lc-product-row-main"><b>${safe(profileName(state.profile))}</b><span>${safe(c.headline || "Live Casino creator")} · Unverified affiliation</span></div></div></section>
        <button class="lc-product-btn" type="submit">CREATE CREATOR PROFILE</button>
      </form>`;
    const select = q('[name="affiliation_type"]');
    select && (select.value = c.affiliation_type || "unlisted");
  }
  function creatorCard(item) {
    const p = item.profile, c = item.creator, next = item.sessions[0], post = item.posts[0], following = state.follows.has(p.id);
    return `<section class="lc-product-cinema compact" data-creator-id="${safe(p.id)}">
      <img src="${safe(visualImage(p))}" alt="">
      <div class="lc-product-cinema-copy">
        <span class="lc-product-label">${safe(sessionStatusLabel(next))}</span>
        <h1>${safe(profileName(p))}</h1>
        <p>${safe(c.headline || "Live Casino creator")} · ${safe((c.games || []).join(", ") || "Live Casino")}</p>
        <div class="lc-product-actions"><button class="lc-product-btn secondary ${following ? "active" : ""}" type="button" data-lc-follow="${safe(p.id)}">${following ? "Following" : "Follow"}</button><button class="lc-product-btn secondary" type="button" data-lc-open-creator="${safe(p.id)}">Open</button>${next ? `<button class="lc-product-btn" type="button" data-lc-live="${safe(next.id)}">${next.status === "live" ? isIllustrativeSession(next) ? "Open demo session" : "Watch live" : "View schedule"}</button>` : ""}</div>
        <span class="lc-product-note">${safe(c.affiliation_name || "Affiliation")} · ${safe(c.affiliation_verification_status || "unverified")}. No operator/provider integration implied.</span>
      </div>
    </section>`;
  }
  function creatorLiveAlertControl(id) {
    if (!state.follows.has(id)) return "";
    const enabled = state.creatorLiveAlerts.get(id) !== !1, globallyPaused = !state.liveSignalsEnabled, available = state.demo || state.returnSignalsAvailable && state.creatorLiveAlertsAvailable, label = globallyPaused ? "Live alerts paused globally" : enabled ? "Mute Live alerts" : "Enable Live alerts";
    return `<button class="lc-product-chip ${enabled && !globallyPaused ? "active" : ""}" type="button" data-lc-creator-live-alerts="${safe(id)}" ${available && !globallyPaused ? "" : "disabled"}>${safe(label)}</button>`;
  }
  function compactCreatorRows(items, emptyText) {
    return items.length ? items.map((item) => {
      const next = item.sessions[0], reason = creatorRecommendationReasons(item).slice(0, 2).join(" · ");
      return `<div class="lc-product-row"><img src="${safe(avatar(item.profile))}" alt=""><span class="lc-product-status-dot ${next?.status === "live" ? "live" : ""}"></span><div class="lc-product-row-main"><b>${safe(profileName(item.profile))}</b><span>${safe(reason || sessionStatusLabel(next))} · ${safe((item.creator.games || []).join(", ") || "Live Casino")}</span></div><button class="lc-product-chip" type="button" data-lc-open-creator="${safe(item.profile.id)}">Open</button></div>`;
    }).join("") : `<div class="lc-product-empty">${safe(emptyText)}</div>`;
  }
  function notificationText(row) {
    if (row.text) return row.text;
    if (row.type === "creator_live") {
      const creator = state.creators.find((item) => item.profile.id === row.creator_id);
      return state.demo ? creator ? `${profileName(creator.profile)} has a demo session available.` : "A Creator demo session is available." : creator ? `${profileName(creator.profile)} is live now.` : "A Creator you follow is live now.";
    }
    return row.type === "new_follower" ? "New follower on your creator profile." : row.type === "post_like" ? "Someone reacted to your content." : row.type === "comment" ? "New comment on your content." : row.type === "comment_reply" ? "New reply in a creator conversation." : "Product activity updated.";
  }
  function renderNotifications(emptyText = "No notifications yet. Follow creators, react to content or save sessions.") {
    const unread = state.notifications.filter((item) => !item.read_at).length;
    return `<section class="lc-product-card"><div class="lc-product-section-head"><h2>Notifications</h2><span>${state.notifications.length ? `${unread} unread` : "Empty"}</span></div>${unread ? '<div class="lc-product-actions"><button class="lc-product-chip" type="button" data-lc-notifications-read>Mark all read</button></div>' : ""}${state.notifications.length ? state.notifications.map((n) => `<div class="lc-product-row ${n.read_at ? "" : "unread"}"><div class="lc-product-row-main"><b>${safe(notificationText(n))}</b><span>${safe(dateLabel(n.created_at))}</span></div><button class="lc-product-chip" type="button" data-lc-notification="${safe(n.id)}">Open</button></div>`).join("") : `<div class="lc-product-empty">${safe(emptyText)}</div>`}</section>`;
  }
  function activitySignalMeta(row) {
    const sessionEntry = findSessionEntry(row.target_id), creator = state.creators.find((item) => item.profile.id === row.creator_id) || sessionEntry?.entry || state.creators.find((item) => item.profile.id === row.target_id), type = row.type || row.signal_type || (isPresentedLive(sessionEntry?.session) || /live now/i.test(notificationText(row)) ? "creator_live" : "activity");
    return type === "creator_live" ? { icon: "●", eyebrow: isIllustrativeSession(sessionEntry?.session) ? sessionStatusLabel(sessionEntry.session) : "LIVE NOW", creator } : type === "new_follower" ? { icon: "+", eyebrow: "NEW FOLLOWER", creator } : type === "post_like" ? { icon: "♥", eyebrow: "REACTION", creator } : ["comment", "comment_reply"].includes(type) ? { icon: "◎", eyebrow: "CONVERSATION", creator } : { icon: "◇", eyebrow: "UPDATE", creator };
  }
  function renderActivitySignals(emptyText) {
    return state.notifications.length ? `<section class="lc-v4-signal-list" aria-label="Recent activity">${state.notifications.map((row) => {
      const meta = activitySignalMeta(row), visual = meta.creator ? `<img src="${safe(avatar(meta.creator.profile))}" alt="">` : `<span aria-hidden="true">${meta.icon}</span>`;
      return `<button class="lc-v4-signal ${row.read_at ? "" : "unread"}" type="button" data-lc-notification="${safe(row.id)}"><span class="lc-v4-signal-avatar">${visual}</span><span class="lc-v4-signal-copy"><small>${safe(meta.eyebrow)}</small><b>${safe(notificationText(row))}</b><time datetime="${safe(row.created_at)}">${safe(dateLabel(row.created_at))}</time></span><i aria-hidden="true">›</i></button>`;
    }).join("")}</section>` : `<section class="lc-v4-activity-empty"><span aria-hidden="true">♡</span><h2>Your activity starts with a follow.</h2><p>${safe(emptyText)}</p><button class="lc-product-btn" type="button" data-lc-product="explore">EXPLORE CREATORS</button></section>`;
  }
  async function markNotificationsRead(ids) {
    const unread = state.notifications.filter((item) => !item.read_at && (!ids || ids.includes(item.id)));
    if (!unread.length) return;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    unread.forEach((item) => {
      item.read_at = now;
    });
  }
  async function openNotification(id) {
    const notification = state.notifications.find((item) => item.id === id);
    if (!notification) return;
    await markNotificationsRead([id]);
    const session = findSessionEntry(notification.target_id);
    if (notification.source === "return_signal" && session)
      trackProductEvent("notification_response", {
        creatorId: session.entry.profile.id,
        sessionId: session.session.id,
        dedupeKey: `notification:${notification.id}`,
        metadata: { notification_type: notification.type || "creator_live" }
      });
    else {
      const creator = state.creators.find((item) => item.profile.id === notification.target_id);
      creator && trackProductEvent("notification_response", {
        creatorId: creator.profile.id,
        dedupeKey: `notification:${notification.id}`,
        metadata: { notification_type: notification.type || "profile_activity" }
      });
    }
    if (session) return renderLive(notification.target_id);
    if (state.creators.some((item) => item.profile.id === notification.target_id)) return renderCreatorDetail(notification.target_id);
    routeHome();
  }
  function suggestedCreators() {
    const query = state.search.trim().toLowerCase();
    return [...(query ? state.creators.filter((item) => [profileName(item.profile), item.profile.username, item.profile.bio, item.creator.headline, ...item.creator.games || [], ...item.creator.languages || []].join(" ").toLowerCase().includes(query)) : state.creators).filter((item) => {
      const session = item.sessions[0], status = session?.status;
      return state.discoveryFilter === "live" ? isPresentedLive(session) : state.discoveryFilter === "following" ? state.follows.has(item.profile.id) : state.discoveryFilter === "upcoming" ? status === "scheduled" || isSessionPreview(session) : !0;
    })].sort((a, b) => creatorDiscoveryScore(b) - creatorDiscoveryScore(a) || profileName(a.profile).localeCompare(profileName(b.profile)));
  }
  function creatorDiscoveryScore(item) {
    const gamePrefs = new Set(state.player?.favorite_games || []), languagePrefs = new Set(state.player?.preferred_languages || []), session = item.sessions[0];
    let score = 0;
    return isPresentedLive(session) && (score += 80), state.follows.has(item.profile.id) && (score += 60), session && state.reminders.has(session.id) && (score += 45), score += Math.min(2, (item.creator.games || []).filter((value) => gamePrefs.has(value)).length) * 30, score += Math.min(2, (item.creator.languages || []).filter((value) => languagePrefs.has(value)).length) * 15, session?.status === "scheduled" && (score += 10), score;
  }
  function creatorRecommendationReasons(item) {
    const gamePrefs = new Set(state.player?.favorite_games || []), languagePrefs = new Set(state.player?.preferred_languages || []), session = item.sessions[0], matchedGame = (item.creator.games || []).find((value) => gamePrefs.has(value)), matchedLanguage = (item.creator.languages || []).find((value) => languagePrefs.has(value));
    return [
      isPresentedLive(session) || isSessionPreview(session) ? sessionStatusLabel(session) : null,
      state.follows.has(item.profile.id) ? "Following" : null,
      session && state.reminders.has(session.id) ? "Reminder set" : null,
      matchedGame ? `Matches ${matchedGame}` : null,
      matchedLanguage || null,
      session?.status === "scheduled" ? "Starting soon" : null
    ].filter(Boolean);
  }
  function savedScheduleEntries() {
    return state.creators.flatMap((entry) => entry.sessions.filter((session) => session.status === "scheduled" && new Date(session.starts_at).getTime() > productNow() && state.reminders.has(session.id)).map((session) => ({ entry, session }))).sort((a, b) => new Date(a.session.starts_at) - new Date(b.session.starts_at));
  }
  function renderSavedSchedule() {
    const saved = savedScheduleEntries();
    return `<section class="lc-v4-saved-schedule"><div class="lc-v4-social-section-head"><div><span>NEXT LIVE</span><h2>My schedule</h2></div><b>${saved.length}</b></div>${saved.length ? `<div class="lc-v4-schedule-strip">${saved.map(({ entry, session }) => `<button class="lc-v4-schedule-card" type="button" data-lc-live="${safe(session.id)}"><img src="${safe(visualImage(entry.profile))}" alt="" loading="lazy" decoding="async"><span class="lc-v4-feed-gradient"></span><span class="lc-v4-schedule-copy"><small>${safe(dateLabel(session.starts_at))}</small><b>${safe(profileName(entry.profile))}</b><em>${safe(session.game)}</em></span></button>`).join("")}</div>` : '<div class="lc-v4-inline-empty"><p>Save an upcoming Creator session and it will stay here as your return plan. In this build, push, email and SMS are not enabled.</p><button class="lc-product-chip" type="button" data-lc-product="explore">FIND A SESSION</button></div>'}</section>`;
  }
  function socialFeedEntries() {
    return suggestedCreators().flatMap((item) => {
      const session = item.sessions[0] || null, posts = item.posts.length ? item.posts.slice(0, 2) : [];
      return !posts.length && session ? [{ item, session, post: null }] : posts.map((post, index) => ({ item, session: index === 0 ? session : null, post }));
    }).sort((a, b) => {
      const aLive = isPresentedLive(a.session) ? 1 : 0, bLive = isPresentedLive(b.session) ? 1 : 0;
      return aLive !== bLive ? bLive - aLive : new Date(b.post?.created_at || b.session?.starts_at || 0) - new Date(a.post?.created_at || a.session?.starts_at || 0);
    });
  }
  function renderSocialPost({ item, session, post }, index) {
    const creatorId = item.profile.id, following = state.follows.has(creatorId), liked = !!(post && demoStore.likes.has(post.id)), comments = post ? demoStore.comments.filter((comment) => comment.post_id === post?.id).length : 0, isLive = isPresentedLive(session), preview = isSessionPreview(session), reminderSet = !!(session && state.reminders.has(session.id)), mediaAlt = `${profileName(item.profile)} at a Live Casino table`, image = `<img ${state.demo && index > 0 ? "data-lc-feed-src" : "src"}="${safe(visualImage(item.profile))}" alt="${safe(mediaAlt)}" loading="${index === 0 ? "eager" : "lazy"}" fetchpriority="${index === 0 ? "high" : "low"}" decoding="async">`, media = state.demo && creatorId === "demo-sofia" ? `<picture><source type="image/avif" srcset="app_prototype_assets/dealers/dealer_sofia_avatar_v1.avif">${image}</picture>` : image;
    return `<article class="lc-v4-feed-post" data-lc-feed-position="${index + 1}">
      <header class="lc-v4-feed-author">
        <button class="lc-v4-feed-avatar" type="button" aria-label="Open ${safe(profileName(item.profile))}'s profile" data-lc-open-creator="${safe(creatorId)}"><img src="${safe(avatar(item.profile))}" ${avatarSizes(item.profile, 40)} alt="" loading="lazy" decoding="async" fetchpriority="low"></button>
        <button class="lc-v4-feed-identity" type="button" data-lc-open-creator="${safe(creatorId)}"><b>${safe(profileName(item.profile))}</b><span>${safe(item.creator.headline || (item.creator.games || []).join(" · ") || "Live Casino creator")}${isIllustrativeProfile(item.profile) ? " · Illustrative profile" : ""}</span></button>
        <button class="lc-product-chip ${following ? "active" : ""}" type="button" data-lc-follow="${safe(creatorId)}">${following ? "Following" : "Follow"}</button>
      </header>
      <button class="lc-v4-feed-media" type="button" ${session ? `data-lc-live="${safe(session.id)}"` : `data-lc-open-creator="${safe(creatorId)}"`}>
        ${media}
        <span class="lc-v4-feed-gradient"></span>
        <span class="lc-v3-live-pill ${isLive ? "is-live" : ""}">${safe(sessionStatusLabel(session))}</span>
        ${session ? `<span class="lc-v4-feed-session"><b>${safe(session.game)}</b><small>${safe(isLive ? session.title || sessionStatusLabel(session) : dateLabel(session.starts_at))}</small></span>` : ""}
      </button>
      <div class="lc-v4-feed-actions">
        <div>
          ${post ? `<button class="lc-v4-icon-action ${liked ? "active" : ""}" type="button" data-lc-like="${safe(post.id)}" aria-label="Like post" ${state.demo ? `aria-pressed="${liked}"` : ""}><span aria-hidden="true">${liked ? "♥" : "♡"}</span><small>${liked ? "Liked" : "Like"}</small></button>` : ""}
          <button class="lc-v4-icon-action" type="button" data-lc-open-creator="${safe(creatorId)}" aria-label="Open creator profile"><span aria-hidden="true">◎</span><small>Profile</small></button>
        </div>
        ${session ? isLive ? `<button class="lc-product-btn lc-v4-feed-cta" type="button" data-lc-live="${safe(session.id)}">${state.demo ? "OPEN DEMO WITH" : "PLAY WITH"} ${safe(profileName(item.profile)).toUpperCase()}</button>` : preview ? `<button class="lc-product-btn lc-v4-feed-cta" type="button" data-lc-live="${safe(session.id)}">OPEN SESSION PREVIEW</button>` : `<button class="lc-product-chip ${reminderSet ? "active" : ""}" type="button" data-lc-reminder="${safe(session.id)}">${reminderSet ? "REMINDER SET" : "REMIND ME"}</button>` : ""}
      </div>
      <div class="lc-v4-feed-caption"><b>${safe(profileName(item.profile))}</b><p ${post && !demoPosts.some((seed) => seed.id === post.id) ? "data-lc-user-content" : ""}>${safe(post?.body || item.profile.bio || "Follow this creator to see their next Live session.")}</p><time datetime="${safe(post?.created_at || session?.starts_at || "")}">${safe(dateLabel(post?.created_at || session?.starts_at || Date.now()))}</time></div>
      ${post ? `<form class="lc-v4-feed-comment" data-lc-form="comment" data-post-id="${safe(post.id)}"><label class="sr-only" for="comment-${safe(post.id)}">Comment on ${safe(profileName(item.profile))}'s post</label><input id="comment-${safe(post.id)}" class="lc-product-input" name="body" maxlength="500" placeholder="Add a comment…"><button type="submit">Post comment</button>${comments ? `<span>${comments} demo comment${comments === 1 ? "" : "s"}</span>` : ""}</form>${state.demo ? demoStore.comments.filter((comment) => comment.post_id === post?.id).map((comment) => `<p class="lc-product-note"><b>You:</b> <span data-lc-user-content>${safe(comment.body)}</span></p>`).join("") : ""}` : ""}
    </article>`;
  }
  let feedImageObserver;
  function loadVisibleFeedImages() {
    feedImageObserver?.disconnect();
    const root = q("#lcProductShell"), pending = qa("img[data-lc-feed-src]", root), load = (image) => {
      image.src = image.dataset.lcFeedSrc, delete image.dataset.lcFeedSrc;
    };
    if (typeof IntersectionObserver > "u") return pending.forEach(load);
    feedImageObserver = new IntersectionObserver((entries) => {
      for (const entry of entries) entry.isIntersecting && (load(entry.target), feedImageObserver.unobserve(entry.target));
    }, { root, rootMargin: "120px" }), pending.forEach((image) => feedImageObserver.observe(image));
  }
  function renderPlayerHome() {
    const creators = suggestedCreators(), liveCreators = creators.filter((item) => isPresentedLive(item.sessions[0])), railCreators = state.demo ? creators.filter((item) => isSessionPreview(item.sessions[0])) : liveCreators, feed = socialFeedEntries(), unread = state.notifications.filter((item) => !item.read_at).length;
    shell().innerHTML = `${top("Home", unread ? `${unread} new signal${unread === 1 ? "" : "s"}` : "Live Casino through people")}
      <div class="lc-product-stack lc-v4-social-home">
        <div class="sr-only" aria-label="LC core loop"><span>Discover</span><span>Creator</span><span>Follow</span><span>Live</span><span>Return</span></div>
        <section class="lc-v4-live-rail" aria-label="${state.demo ? "Creators in demo live sessions" : "Creators live now"}">
          <button class="lc-v4-live-orb lc-v4-explore-orb" type="button" data-lc-product="explore"><span>+</span><small>Explore</small></button>
          ${railCreators.slice(0, 8).map((item) => `<button class="lc-v4-live-orb" type="button" data-lc-live="${safe(item.sessions[0].id)}"><span><img src="${safe(avatar(item.profile))}" ${avatarSizes(item.profile)} alt="" loading="lazy" decoding="async" fetchpriority="low"><i aria-label="${safe(sessionStatusLabel(item.sessions[0]))}">${state.demo ? "PREVIEW" : safe(sessionStatusLabel(item.sessions[0]))}</i></span><small>${safe(profileName(item.profile).split(" ")[0])}</small></button>`).join("")}
        </section>
        <div class="lc-v4-home-switch"><button class="${state.discoveryFilter === "for_you" ? "active" : ""}" type="button" data-lc-home-filter="for_you">For you</button><button class="${state.discoveryFilter === "following" ? "active" : ""}" type="button" data-lc-home-filter="following">Following</button></div>
        <section class="lc-v4-social-feed" aria-label="Creator feed">
          ${feed.length ? feed.map(renderSocialPost).join("") : '<div class="lc-v4-feed-empty"><span>YOUR FEED</span><h1>Find people worth returning for.</h1><p>Explore verified, public Creator profiles and follow the people you want to see Live.</p><button class="lc-product-btn" type="button" data-lc-product="explore">EXPLORE CREATORS</button></div>'}
        </section>
        <section class="lc-v4-feed-boundary"><b>LC connects you to people, not funds.</b><span>Gameplay and all regulated casino operations stay with the licensed operator.</span></section>
      </div>${tabs("home")}`, loadVisibleFeedImages(), feed.slice(0, 20).forEach(({ item }, index) => void trackProductEvent("creator_impression", { creatorId: item.profile.id, dedupeKey: `home-feed:${state.discoveryFilter}:${item.profile.id}:${index}`, metadata: { surface: "creator_feed", position: index + 1, filter: state.discoveryFilter, recommendation_reasons: creatorRecommendationReasons(item).slice(0, 4), experience: "social_home_feed" } }));
  }
  function renderSocialExplore() {
    const creators = suggestedCreators(), liveCreators = creators.filter((item) => isPresentedLive(item.sessions[0])), upcomingCreators = creators.filter((item) => item.sessions[0]?.status === "scheduled"), contentEntries = creators.flatMap((item) => item.posts.slice(0, 2).map((post) => ({ item, post }))).slice(0, 8), filters = { for_you: "For you", live: "Live", following: "Following", upcoming: "Soon" }, resultContext = state.search ? `${creators.length} result${creators.length === 1 ? "" : "s"} for “${safe(state.search)}”` : state.discoveryFilter === "for_you" ? "Based on your selected games, languages and follows" : `${creators.length} creator${creators.length === 1 ? "" : "s"} in this view`, personCard = (item, index) => {
      const session = item.sessions[0], following = state.follows.has(item.profile.id), reasons = creatorRecommendationReasons(item).slice(0, 3);
      return `<article class="lc-v4-person-card" data-lc-explore-position="${index + 1}">
        <button type="button" class="lc-v4-person-media" data-lc-open-creator="${safe(item.profile.id)}"><img src="${safe(visualImage(item.profile))}" alt="${safe(profileName(item.profile))} creator profile" loading="lazy" decoding="async"><span class="lc-v3-live-pill ${isPresentedLive(session) ? "is-live" : ""}">${safe(sessionStatusLabel(session))}</span></button>
        <div class="lc-v4-person-copy"><button type="button" class="lc-v4-person-identity" data-lc-open-creator="${safe(item.profile.id)}"><b>${safe(profileName(item.profile))}</b><span>${safe(item.creator.headline || (item.creator.games || []).slice(0, 2).join(" · ") || "Live Casino creator")}${isIllustrativeProfile(item.profile) ? " · Illustrative profile" : ""}</span></button><button class="lc-product-chip ${following ? "active" : ""}" type="button" data-lc-follow="${safe(item.profile.id)}">${following ? "Following" : "Follow"}</button></div>
        ${reasons.length ? `<div class="lc-v4-reason-row" aria-label="Why this creator">${reasons.map((reason) => `<span>${safe(reason)}</span>`).join("")}</div>` : ""}
      </article>`;
    };
    shell().innerHTML = `${top("Explore", "Find the person behind the table.")}
      <div class="lc-product-stack lc-v4-explore">
        ${state.demo ? '<section class="lc-demo-games" aria-label="Live Casino lobby"><button type="button" data-lc-demo-game="Blackjack"><b>Blackjack</b><span>Discover dealers · scripted table preview</span></button><button type="button" data-lc-demo-game="Baccarat"><b>Baccarat</b><span>Discover dealers · scripted table preview</span></button></section>' : ""}
        <section class="lc-v4-explore-hero"><div><span>DISCOVER PEOPLE</span><h1>Find your next Live table through a Creator.</h1><p>${state.demo ? "Explore illustrative creators and preview the path to participating licensed operators." : "Search by person, game or language and find creators relevant to your interests."}</p></div><div class="lc-v4-explore-state"><b>${liveCreators.length}</b><span>${state.demo ? "Connected broadcasts (demo has none)" : "Live in this view"}</span></div></section>
        <form class="lc-v4-explore-search" data-lc-form="search"><input class="lc-product-input" name="search" maxlength="80" aria-label="Search creators, games or languages" placeholder="Search creators, games or languages" value="${safe(state.search)}"><button class="lc-product-btn" type="submit">SEARCH</button>${state.search ? '<button class="lc-product-chip" type="button" data-lc-clear-search>Clear</button>' : ""}</form>
        <div class="lc-v4-explore-controls"><div class="lc-v4-filter-row" aria-label="Explore filters">${Object.entries(filters).map(([value, label]) => `<button class="lc-product-chip ${state.discoveryFilter === value ? "active" : ""}" type="button" data-lc-discovery-filter="${value}">${label}</button>`).join("")}</div><p aria-live="polite">${resultContext}</p></div>
        ${liveCreators.length ? `<section class="lc-v4-discovery-section lc-v4-live-discovery"><div class="lc-v4-social-section-head"><div><span>${state.demo ? "DEMO LIVE" : "LIVE NOW"}</span><h2>Join the person, then choose where to play.</h2></div><b>${liveCreators.length}</b></div><div class="lc-v4-live-discovery-row">${liveCreators.map((item) => {
      const session = item.sessions[0];
      return `<article><button type="button" data-lc-live="${safe(session.id)}"><img src="${safe(visualImage(item.profile))}" alt="${safe(profileName(item.profile))} ${safe(sessionStatusLabel(session))} session"><span class="lc-v4-feed-gradient"></span><i>${safe(sessionStatusLabel(session))}</i><div><b>${safe(profileName(item.profile))}</b><small>${safe(session.game || "Live Casino")}</small></div></button></article>`;
    }).join("")}</div></section>` : ""}
        <section class="lc-v4-discovery-section"><div class="lc-v4-social-section-head"><div><span>${state.discoveryFilter === "for_you" ? "FOR YOU" : safe(filters[state.discoveryFilter] || "RESULTS")}</span><h2>${state.discoveryFilter === "for_you" ? "Creators matched to your social signals." : "Creators in this view."}</h2></div><b>${creators.length}</b></div><div class="lc-v4-explore-grid">${creators.length ? creators.map(personCard).join("") : '<div class="lc-product-empty"><h2>No creators found</h2><p>Try another name, game, language or feed filter.</p></div>'}</div></section>
        ${upcomingCreators.length ? `<section class="lc-v4-discovery-section"><div class="lc-v4-social-section-head"><div><span>UP NEXT</span><h2>Save a reason to return.</h2></div><b>${upcomingCreators.length}</b></div><div class="lc-v4-upcoming-list">${upcomingCreators.slice(0, 6).map((item) => {
      const session = item.sessions[0], saved = state.reminders.has(session.id);
      return `<article><button type="button" class="lc-v4-upcoming-person" data-lc-open-creator="${safe(item.profile.id)}"><img src="${safe(avatar(item.profile))}" alt=""><span><b>${safe(profileName(item.profile))}</b><small>${safe(session.title || session.game || "Live session")}</small></span></button><time>${safe(sessionLine(session))}</time><button class="lc-product-chip ${saved ? "active" : ""}" type="button" data-lc-reminder="${safe(session.id)}">${saved ? "Saved" : "Remind me"}</button></article>`;
    }).join("")}</div></section>` : ""}
        ${contentEntries.length && state.discoveryFilter === "for_you" ? `<section class="lc-v4-discovery-section"><div class="lc-v4-social-section-head"><div><span>RECENT CONTENT</span><h2>Meet Creators before they go Live.</h2></div></div><div class="lc-v4-content-discovery">${contentEntries.map(({ item, post }) => `<button type="button" data-lc-open-creator="${safe(item.profile.id)}"><img src="${safe(visualImage(item.profile))}" alt="" loading="lazy" decoding="async"><span class="lc-v4-feed-gradient"></span><div><b>${safe(profileName(item.profile))}</b><p ${demoPosts.some((seed) => seed.id === post.id) ? "" : "data-lc-user-content"}>${safe(post.body)}</p></div></button>`).join("")}</div></section>` : ""}
        <section class="lc-v4-feed-boundary"><b>Discovery stays inside LC. Gameplay does not.</b><span>Any Play action continues through an eligible licensed operator destination; LC does not handle funds, KYC or wagering.</span></section>
      </div>${tabs("explore")}`, creators.slice(0, 20).forEach((item, index) => void trackProductEvent("creator_impression", { creatorId: item.profile.id, dedupeKey: `explore:${state.discoveryFilter}:${item.profile.id}`, metadata: { surface: "explore", position: index + 1, filter: state.discoveryFilter, recommendation_reasons: creatorRecommendationReasons(item).slice(0, 4), experience: "social_explore" } }));
  }
  function renderSocialActivity() {
    const unread = state.notifications.filter((item) => !item.read_at).length, saved = savedScheduleEntries();
    shell().innerHTML = `${top("Activity", unread ? `${unread} new signal${unread === 1 ? "" : "s"}` : "You're caught up")}
      <div class="lc-product-stack lc-v4-activity" data-lc-activity>
        <section class="lc-v4-activity-head"><div><span class="lc-v3-kicker">ACTIVITY</span><h1>People worth coming back for.</h1><p>Live signals, reactions and reminders from your social circle.</p></div><div class="lc-v4-activity-counters"><span><b>${unread}</b> new</span><span><b>${saved.length}</b> saved</span></div></section>
        <div class="lc-v4-social-section-head"><div><span>NOW</span><h2>Recent activity</h2></div>${unread ? '<button class="lc-product-chip" type="button" data-lc-notifications-read>Mark all read</button>' : ""}</div>
        ${renderActivitySignals("Follow creators or save a session and LC will keep the relationship connected.")}
        ${renderSavedSchedule()}
        <p class="lc-v4-privacy-note"><b>Private by design.</b> In-app only. No email, SMS or push delivery is implied.</p>
      </div>${tabs("activity")}`;
  }
  function renderSocialCreate() {
    if (state.current?.persona === "creator" && state.creator?.onboarding_completed) return renderCreatorHome();
    shell().innerHTML = `${top("Create", "Creator tools live inside the social app")}
      <div class="lc-product-stack lc-v4-create-gateway">
        <section class="lc-v4-create-hero"><div><span class="lc-v3-kicker">CREATOR MODE</span><h1>Turn a table presence into a followable identity.</h1><p>Publish content, schedule your next session and tell followers when you are Live.</p></div><button class="lc-product-btn" type="button" data-lc-persona="creator">OPEN CREATOR TOOLS</button></section>
        <section class="lc-v4-create-options"><article><span>01</span><h2>Share</h2><p>Post a short update around your work and next Live moment.</p></article><article><span>02</span><h2>Schedule</h2><p>Give followers a specific reason and time to return.</p></article><article><span>03</span><h2>Go Live</h2><p>Signal followers only after verification and public-session checks pass.</p></article></section>
        <p class="lc-product-note">Creator verification and affiliation approval remain server-controlled. Opening Creator tools never grants approval.</p>
      </div>${tabs("create")}`;
  }
  function creatorStudioNavigation(active) {
    return `<nav class="lc-v4-studio-nav" aria-label="Creator tools">${[["overview", "Studio"], ["post", "Post"], ["schedule", "Schedule"], ["live", "Live"], ["audience", "Audience"]].map(([id, label]) => `<button class="${active === id ? "active" : ""}" type="button" data-lc-creator-studio="${id}">${label}</button>`).join("")}</nav>`;
  }
  function creatorSessionCard(session, publication, mode = "schedule") {
    const isScheduled = session.status === "scheduled", isLive = session.status === "live", canPublish = publication.publicReady && isScheduled;
    return `<article class="lc-v4-studio-session ${isLive ? "is-live" : ""}">
      <div class="lc-v4-studio-session-time"><span>${isLive ? "LIVE" : state.demo ? "SAMPLE SCHEDULE" : new Date(session.starts_at).toLocaleDateString(document.documentElement.lang === "ru" ? "ru-RU" : "en-GB", { month: "short", day: "numeric" })}</span><b>${isLive ? "NOW" : dateLabel(session.starts_at)}</b></div>
      <div class="lc-v4-studio-session-copy"><span>${safe(session.game)} · ${safe(session.visibility || "private")}</span><h3>${safe(session.title || "Live session")}</h3><p>${safe(session.operator_name || "Operator context not set")}</p></div>
      <div class="lc-v4-studio-session-actions">
        ${canPublish ? `<button class="lc-product-chip" type="button" data-lc-session-visibility="${session.visibility === "public" ? "private" : "public"}" data-lc-session-id="${safe(session.id)}">${session.visibility === "public" ? "Make private" : "Publish"}</button>` : ""}
        ${mode === "live" && session.visibility === "public" && isScheduled ? `<button class="lc-product-btn" type="button" data-lc-session-status="live" data-lc-session-id="${safe(session.id)}">GO LIVE</button>` : ""}
        ${isLive ? `<button class="lc-product-btn secondary" type="button" data-lc-session-status="completed" data-lc-session-id="${safe(session.id)}">END LIVE</button>` : ""}
        ${["scheduled", "live"].includes(session.status) ? `<button class="lc-product-chip" type="button" data-lc-session-status="cancelled" data-lc-session-id="${safe(session.id)}">Cancel</button>` : ""}
      </div>
    </article>`;
  }
  function renderCreatorHome() {
    const c = state.creator, publication = creatorPublication(), reviewCopy = state.demo ? ["Illustrative identity · not verified", "Local preview only. Creator verification and affiliation approval are not claimed."] : creatorReviewCopy(publication.verification), view = (/* @__PURE__ */ new Set(["overview", "post", "schedule", "live", "audience"])).has(state.creatorStudioView) ? state.creatorStudioView : "overview";
    state.creatorStudioView = view;
    const upcoming = state.sessions.filter((item) => item.status === "scheduled").sort((a, b) => new Date(a.starts_at) - new Date(b.starts_at)), liveNow = state.sessions.find((item) => item.status === "live"), publicAction = publication.approved ? `<button class="lc-product-btn ${publication.published ? "secondary" : ""}" type="button" data-lc-creator-profile-status="${publication.published ? "draft" : "published"}">${publication.published ? "MAKE PRIVATE" : "PUBLISH PROFILE"}</button>` : "", views = {
      overview: `<section class="lc-v4-studio-command"><div><span class="lc-v3-kicker">TODAY</span><h2>${liveNow ? state.demo ? "Your demo session is live." : "You are Live." : upcoming[0] ? "Your next return moment is ready." : "Give followers a reason to return."}</h2><p>${liveNow ? safe(liveNow.title) : upcoming[0] ? `${safe(upcoming[0].title)} · ${safe(sessionLine(upcoming[0]))}` : "Share a post or schedule your next Live table."}</p></div><button class="lc-product-btn" type="button" data-lc-creator-studio="${liveNow || upcoming[0] ? "live" : "schedule"}">${liveNow ? state.demo ? "MANAGE DEMO SESSION" : "MANAGE LIVE" : upcoming[0] ? "OPEN LIVE CONTROL" : "SCHEDULE LIVE"}</button></section>
        <section class="lc-v4-studio-quick"><button type="button" data-lc-creator-studio="post"><span>＋</span><b>Create post</b><small>Share an update</small></button><button type="button" data-lc-creator-studio="schedule"><span>◷</span><b>Schedule</b><small>Plan a return</small></button><button type="button" data-lc-creator-studio="live"><span>●</span><b>Live control</b><small>Start when eligible</small></button></section>
        <section class="lc-product-card lc-v4-publication"><div><span class="lc-v3-kicker">PROFILE VISIBILITY</span><h2>${publication.published ? "Your Creator profile is visible" : safe(reviewCopy[0])}</h2><p>${safe(reviewCopy[1])}</p></div><div>${publicAction}<small>Verification remains server-controlled.</small></div></section>`,
      post: `<section class="lc-v4-studio-title"><div><span>CREATE</span><h1>Share with followers</h1><p>Post table context, a short update or what to expect from your next Live session.</p></div></section>
        ${publication.publicReady ? `<form class="lc-v4-post-composer" data-lc-form="post"><div class="lc-v4-post-author"><img src="${safe(avatar(state.profile))}" alt=""><span><b>${safe(profileName(state.profile))}</b><small>Public Creator post</small></span></div><label class="sr-only" for="creator-post-body">Post text</label><textarea id="creator-post-body" class="lc-product-textarea" name="body" maxlength="2000" placeholder="What should your followers know?"></textarea><div><span>Public content · moderation applies</span><button class="lc-product-btn" type="submit">SHARE</button></div></form>` : '<section class="lc-v4-studio-locked"><span>PRIVATE</span><h2>Content unlocks after verification and publication.</h2><p>Your drafts and profile remain private. Approval cannot be granted from this screen.</p></section>'}
        <section class="lc-v4-post-library"><div class="lc-product-section-head"><h2>Your posts</h2><span>${state.posts.length} total</span></div>${state.posts.length ? state.posts.map((post) => `<article><time>${safe(dateLabel(post.created_at))}</time><p ${demoPosts.some((seed) => seed.id === post.id) ? "" : "data-lc-user-content"}>${safe(post.body)}</p><span>${safe(post.status || "active")}</span></article>`).join("") : '<div class="lc-product-empty">No posts yet.</div>'}</section>`,
      schedule: `<section class="lc-v4-studio-title"><div><span>SCHEDULE</span><h1>Plan the next Live moment</h1><p>Followers can save an eligible public session and return for you at the right time.</p></div></section>
        <form class="lc-v4-session-composer" data-lc-form="session"><label><span>Session title</span><input class="lc-product-input" name="title" maxlength="120" placeholder="Evening Blackjack" value="Live table session"></label><label><span>Game</span><select class="lc-product-select" name="game">${games.map((game) => `<option>${safe(game)}</option>`).join("")}</select></label><label><span>Date and time</span><input class="lc-product-input" name="starts_at" type="datetime-local" required></label><label><span>Operator or studio <small>optional · user claimed</small></span><input class="lc-product-input" name="operator_name" maxlength="120" placeholder="Not verified by LC"></label><button class="lc-product-btn" type="submit">${publication.publicReady ? "ADD TO SCHEDULE" : "SAVE PRIVATE SESSION"}</button><p>${publication.publicReady ? "Followers can save this session after it is public." : "This stays private until Creator verification and profile publication are complete."}</p></form>
        <section class="lc-v4-session-list"><div class="lc-product-section-head"><h2>Upcoming</h2><span>${upcoming.length}</span></div>${upcoming.length ? upcoming.map((session) => creatorSessionCard(session, publication)).join("") : '<div class="lc-product-empty">Nothing scheduled yet.</div>'}</section>`,
      live: `<section class="lc-v4-live-control ${liveNow ? "is-live" : ""}"><span>${liveNow ? safe(sessionStatusLabel(liveNow)) : "LIVE CONTROL"}</span><h1>${liveNow ? safe(liveNow.title) : "Start only when the session is ready."}</h1><p>${liveNow ? "Followers with eligible Live signals can return to your public session." : "A session must be scheduled, public and attached to an approved Creator profile before it can go Live."}</p>${liveNow ? creatorSessionCard(liveNow, publication, "live") : ""}</section>
        ${liveNow ? "" : `<section class="lc-v4-session-list"><div class="lc-product-section-head"><h2>Ready to start</h2><span>${upcoming.filter((item) => item.visibility === "public").length}</span></div>${upcoming.length ? upcoming.map((session) => creatorSessionCard(session, publication, "live")).join("") : '<div class="lc-product-empty">Schedule a session first.</div>'}</section>`}
        <section class="lc-v4-studio-boundary"><b>LC controls the social signal, not the game.</b><span>Gameplay, wallet, KYC/AML, wagering, settlement and responsible-gaming operations remain with licensed operator/provider infrastructure.</span></section>`,
      audience: `<section class="lc-v4-studio-title"><div><span>AUDIENCE</span><h1>Understand app-owned activity</h1><p>Only observed LC interactions appear here. Commercial impact remains To be validated.</p></div></section>
        <section class="lc-v4-audience-summary"><article><b>${state.posts.length}</b><span>Published records</span></article><article><b>${upcoming.length}</b><span>Scheduled returns</span></article><article><b>${state.notifications.filter((item) => item.type === "new_follower").length}</b><span>Follower signals</span></article><article><b>To be validated</b><span>Operator value</span></article></section>
        ${renderNotifications("No audience activity yet. New followers, reactions and comments will appear here.")}
        <p class="lc-product-note">Counts are app-owned records, not GGR, CAC, retention or ROI claims.</p>`
    };
    shell().innerHTML = `${top("Create", "Creator studio")}
      <div class="lc-product-stack lc-v4-creator-studio" data-lc-creator-studio-view="${safe(view)}">
        <section class="lc-v4-studio-profile"><img src="${safe(visualImage(state.profile))}" alt=""><div><span class="lc-v3-kicker">CREATOR MODE</span><h1>${safe(profileName(state.profile))}</h1><p>${safe(c.headline || "Live Casino creator")}</p><div class="lc-v4-studio-badges"><span>${safe(state.demo ? "Illustrative identity · not verified" : publication.verification)}</span><span>${publication.published ? "Public profile" : "Private profile"}</span></div></div><button class="lc-product-chip" type="button" data-lc-open-creator="${safe(state.profile.id)}">View public profile</button></section>
        ${creatorStudioNavigation(view)}
        ${views[view]}
      </div>${tabs("create")}`;
    const dt = q('[name="starts_at"]');
    dt && (dt.min = localDateTimeInput(new Date(Date.now() + 3e5)), dt.value || (dt.value = localDateTimeInput(new Date(Date.now() + 864e5))));
  }
  function renderIndustryOnboarding() {
    const subtype = state.current?.industry_subtype || "operator";
    shell().innerHTML = `${top(`${subtype} setup`, "Industry profile")}
      <form class="lc-product-stack lc-product-form" data-lc-form="industry">
        <section class="lc-product-card lc-product-hero"><span class="lc-product-label">Industry</span><h1>${subtype === "provider" ? "Distribution through people." : "Evaluate the Live Casino social layer."}</h1><p>Registration does not mean company verification, partner approval or active integration.</p></section>
        <section class="lc-product-card"><input class="lc-product-input" name="company_name" maxlength="120" required placeholder="Company"><input class="lc-product-input" name="job_title" maxlength="120" required placeholder="Job title"><input class="lc-product-input" name="work_email" maxlength="254" required placeholder="Work email"><input class="lc-product-input" name="website_url" maxlength="300" placeholder="Website (optional)"></section>
        <section class="lc-product-card"><h2>Interests</h2>${checks("interests", interests, state.industry?.interests)}</section>
        <button class="lc-product-btn" type="submit">OPEN INDUSTRY VIEW</button>
      </form>`;
  }
  function renderPilotMeasurementBrief(subtype) {
    if (!state.pilotBriefsAvailable && !state.demo)
      return '<section class="lc-product-card"><div class="lc-product-section-head"><h2>Pilot measurement brief</h2><span>Not available</span></div><p>The planning workspace will become available after its additive database migration is applied.</p><span class="lc-product-note">No product event collection or operator integration is implied.</span></section>';
    const brief = state.pilotBriefs.find((row) => row.industry_subtype === subtype);
    if (brief && brief.status !== "draft") {
      const hypothesis = PILOT_HYPOTHESES.find(([value]) => value === brief.primary_hypothesis)?.[1] || brief.primary_hypothesis, labels = (brief.observed_events || []).map((value) => PILOT_EVENTS.find(([eventName]) => eventName === value)?.[1] || value);
      return `<section class="lc-product-card"><div class="lc-product-section-head"><h2>Pilot measurement brief</h2><span>${safe(brief.status)}</span></div><h3>${safe(hypothesis)}</h3><p>${safe(brief.attribution_window_days)}-day attribution window · ${safe(labels.join(" · "))}</p><span class="lc-product-note">Submitted for review. This records a measurement plan, not validated performance, partner approval or production readiness.</span></section>`;
    }
    const selected = new Set(brief?.observed_events || ["creator_impression", "creator_profile_open", "creator_follow", "live_session_open", "handoff_intent", "handoff_return"]);
    return `<form class="lc-product-card lc-product-form" data-lc-form="pilot-brief">
      <div class="lc-product-section-head"><h2>Pilot measurement brief</h2><span>${brief ? "Draft saved" : "To be validated"}</span></div>
      <p>Define what a first pilot should learn before discussing commercial outcomes.</p>
      <select class="lc-product-select" name="primary_hypothesis">${PILOT_HYPOTHESES.map(([value, label]) => `<option value="${safe(value)}" ${brief?.primary_hypothesis === value ? "selected" : ""}>${safe(label)}</option>`).join("")}</select>
      <label class="lc-product-note" for="pilot-window">Attribution window (1–30 days)</label>
      <input class="lc-product-input" id="pilot-window" name="attribution_window_days" type="number" min="1" max="30" required value="${safe(brief?.attribution_window_days || 7)}">
      <h3>Observed LC events</h3>
      <div class="lc-product-actions">${PILOT_EVENTS.map(([value, label]) => `<label class="lc-product-chip ${selected.has(value) ? "active" : ""}"><input style="display:none" type="checkbox" name="observed_events" value="${safe(value)}" ${selected.has(value) ? "checked" : ""}>${safe(label)}</label>`).join("")}</div>
      <select class="lc-product-select" name="feed_readiness"><option value="not_available">Live feed: not available</option><option value="documentation_available" ${brief?.feed_readiness === "documentation_available" ? "selected" : ""}>Live feed: documentation available</option><option value="sandbox_available" ${brief?.feed_readiness === "sandbox_available" ? "selected" : ""}>Live feed: sandbox available</option></select>
      <select class="lc-product-select" name="handoff_readiness"><option value="not_available">Operator handoff: not available</option><option value="conceptual" ${brief?.handoff_readiness === "conceptual" ? "selected" : ""}>Operator handoff: conceptual URL flow</option><option value="sandbox_available" ${brief?.handoff_readiness === "sandbox_available" ? "selected" : ""}>Operator handoff: sandbox available</option></select>
      <textarea class="lc-product-textarea" name="notes" maxlength="1000" placeholder="Constraints, consent, market rules or data availability (optional)">${safe(brief?.notes || "")}</textarea>
      <div class="lc-product-actions"><button class="lc-product-btn secondary" type="submit" name="pilot_action" value="draft">SAVE DRAFT</button><button class="lc-product-btn" type="submit" name="pilot_action" value="submit">SUBMIT FOR REVIEW</button></div>
      <span class="lc-product-note">Readiness is self-reported and unverified. LC stores app-owned funnel events only; gameplay, wallet, KYC/AML, wagering and settlement remain outside LC.</span>
    </form>`;
  }
  function businessRoleCopy(subtype, isAdmin) {
    return isAdmin ? {
      label: "ADMIN CONTROL",
      title: "Policy, moderation and audit control",
      description: "Review protected platform states without inheriting an operator workspace or exposing tenant data across boundaries.",
      focus: "Platform control"
    } : subtype === "provider" ? {
      label: "PROVIDER OPERATIONS",
      title: "Distribution and identity readiness",
      description: "Prepare normalized Live-product context and creator mappings for tenant-scoped operator delivery.",
      focus: "Distribution readiness"
    } : {
      label: "OPERATOR OPERATIONS",
      title: "Creator acquisition operations",
      description: "Prepare creator, campaign and Live handoff context for a licensed operator environment.",
      focus: "Handoff readiness"
    };
  }
  function businessState(label, tone = "neutral") {
    return `<span class="lc-v4-ops-state is-${safe(tone)}">${safe(state.demo && label === "unverified" ? "Illustrative identity · not verified" : label)}</span>`;
  }
  function businessEmpty(title, body, stateLabel = "Not configured") {
    return `<section class="lc-v4-ops-empty"><span>EMPTY STATE</span><h2>${safe(title)}</h2><p>${safe(body)}</p>${businessState(stateLabel)}</section>`;
  }
  function renderPerformanceWorkspace(subtype, isAdmin) {
    const instrumentationLabel = state.demo ? "Contract preview" : state.analyticsAvailable ? "Contract available" : "Not available", instrumentationTone = state.analyticsAvailable ? "ready" : "locked", brief = state.pilotBriefs.find((row) => row.industry_subtype === subtype), attributionWindow = brief?.attribution_window_days ? `${safe(brief.attribution_window_days)} days · plan only` : "To be validated", eventRows = [
      ["creator_impression", "Creator card or content enters the visible discovery surface"],
      ["creator_profile_open", "A person opens an eligible Creator profile"],
      ["creator_follow", "A person follows an eligible Creator"],
      ["live_session_open", "A person opens an eligible Creator Live session"],
      ["handoff_intent", "A person initiates navigation to a server-validated licensed-operator destination"],
      ["handoff_return", "A person returns to LC with attributable handoff context"]
    ].map(([eventName, definition]) => `<tr><td><code>${safe(eventName)}</code></td><td>${safe(definition)}</td><td>${businessState(instrumentationLabel, instrumentationTone)}</td><td>${businessState("No count loaded", "neutral")}</td></tr>`).join(""), validationStages = [
      ["01", "Instrumented", "Named, first-party event contract exists in LC.", instrumentationLabel, instrumentationTone],
      ["02", "Observed", "Event records must be collected in the authorized tenant scope.", "Not evidenced", "pending"],
      ["03", "Reconciled", "Handoff and return context must pass data-quality checks.", "Not evidenced", "pending"],
      ["04", "Customer-confirmed", "Any outcome claim requires licensed operator confirmation.", "To be validated", "locked"]
    ].map(([index, title, body, label, tone]) => `<article><span>${safe(index)}</span><div><b>${safe(title)}</b><p>${safe(body)}</p></div>${businessState(label, tone)}</article>`).join(""), adminBoundary = isAdmin ? businessEmpty("No authorized evidence review", "Cross-tenant evidence is never aggregated in this client. An explicit privileged backend scope is required to inspect tenant records.", "Protected") : renderPilotMeasurementBrief(subtype);
    return `<section class="lc-v4-business-title"><div><span>EVIDENCE WORKSPACE</span><h1>Performance</h1><p>Separate event instrumentation, observed records and externally confirmed outcomes before making a performance claim.</p></div>${businessState("No commercial claims", "ready")}</section>
      <section class="lc-v4-evidence-gates" aria-label="Evidence readiness">
        <article><span>LC EVENT INSTRUMENTATION</span><b>${safe(instrumentationLabel)}</b><p>A defined event name is not an observed result.</p></article>
        <article><span>ATTRIBUTION WINDOW</span><b>${attributionWindow}</b><p>A saved brief records a plan, not validated causality.</p></article>
        <article><span>OPERATOR OUTCOMES</span><b>Not available</b><p>Gameplay, deposits, wagering and settlement remain outside LC.</p></article>
        <article><span>COMMERCIAL VALIDATION</span><b>To be validated</b><p>CAC, retention, GGR and ROI need observed, reconciled evidence.</p></article>
      </section>
      <section class="lc-product-card lc-v4-event-contract"><div class="lc-product-section-head"><div><small>MEASUREMENT CONTRACT</small><h2>App-owned event taxonomy</h2></div><span>No result values</span></div><div class="lc-v4-table-wrap"><table class="lc-v4-table"><thead><tr><th>Event</th><th>Definition</th><th>Instrumentation</th><th>Evidence</th></tr></thead><tbody>${eventRows}</tbody></table></div><p class="lc-product-note">Event availability is evaluated inside the authorized account and tenant scope. Contract presence never implies volume, performance or partner validation.</p></section>
      <section class="lc-product-card lc-v4-validation-ladder"><div class="lc-product-section-head"><div><small>CLAIM GATE</small><h2>Evidence validation ladder</h2></div><span>Fail closed</span></div><div>${validationStages}</div></section>
      ${adminBoundary}
      <section class="lc-product-card lc-v4-ops-boundary"><div><span>LC CAN EVIDENCE</span><b>Discovery · profile open · follow · Live open · handoff intent · attributable return</b></div><div><span>LC CANNOT EVIDENCE ALONE</span><b>Gameplay · deposits · wagering · settlement · responsible gaming · commercial impact</b></div></section>`;
  }
  function renderLocalBusinessScenario(provider) {
    const draft = provider ? demoStore.mapping : demoStore.campaign;
    return `<section class="lc-product-card lc-local-scenario"><span class="lc-product-label">LOCAL DEMO WORKFLOW</span><h2>${provider ? "Map a creator to a sample catalog" : "Prepare a creator-led campaign"}</h2><p>${provider ? "Keep creator identity and table context connected before operator delivery." : "Follow discovery through handoff intent and return. Commercial outcomes remain unvalidated."}</p><form data-lc-form="${provider ? "demo-mapping" : "demo-campaign"}"><label for="local-context">${provider ? "Sample catalog reference" : "Local campaign name"}</label><input id="local-context" class="lc-product-input" name="context" maxlength="80" required value="${safe(draft || (provider ? "sample-blackjack-table" : window.LCDemoLocale?.translate("Sofia discovery preview") || "Sofia discovery preview"))}"><p>Sofia Laurent · Blackjack · Illustrative identity · not verified</p><button class="lc-product-btn" type="submit">${provider ? "Save local mapping draft" : "Save local campaign draft"}</button></form>${draft ? `<p role="status">Local draft saved. No partner approval or connection is implied.</p><button class="lc-product-btn secondary" type="button" data-lc-live="demo-session-sofia">${provider ? "Preview mapped session" : "Try the player handoff journey"}</button>` : ""}</section>`;
  }
  function renderLocalTrace() {
    const labels = { creator_impression: "Creator viewed", creator_profile_open: "Profile opened", creator_follow: "Creator followed", live_session_open: "Session opened", schedule_reminder: "Reminder saved", handoff_intent: "Handoff preview opened", handoff_return: "Returned to LC", local_campaign_draft: "Local campaign draft saved", local_mapping_draft: "Local catalog mapping saved" };
    return `<section class="lc-product-card lc-local-trace"><span class="lc-product-label">THIS BROWSER SESSION ONLY</span><h2>Your local journey evidence</h2><p>Only actions taken in this demo appear here. These records are not operator outcomes, ROI or a validated pilot.</p>${demoStore.trace.length ? `<ol>${demoStore.trace.map((row) => `<li><b>${safe(labels[row.name] || "Local demo action")}</b><span>${safe(row.creator ? profileName(demoProfile(row.creator)) : row.session && demoSessions.find((session) => session.id === row.session)?.title || "Local demo")} · ${dateLabel(row.at)}</span></li>`).join("")}</ol>` : "<p>No actions recorded yet. Save a draft and try the session preview.</p>"}</section>`;
  }
  function renderIndustryHome(view = state.businessView) {
    const subtype = state.industry?.subtype || state.current?.industry_subtype || "operator", request = state.accessRequests.find((row) => row.industry_subtype === subtype), provider = subtype === "provider", isAdmin = subtype === "admin" || ["admin", "moderator"].includes(state.profile?.role), role = businessRoleCopy(subtype, isAdmin), sessions = state.creators.flatMap((item) => item.sessions.map((session) => ({ item, session }))), liveSessions = sessions.filter(({ session }) => isPresentedLive(session)), statusText = request?.status || state.industry?.access_status || (isAdmin ? "protected role" : "not requested"), status = safe(statusText), recordScope = state.demo ? "Illustrative demo records" : "Tenant-scoped records", creatorRows = state.creators.slice(0, 12).map((item) => {
      const creatorStatus = item.creator.verification_status || "unverified", publication = item.creator.profile_status || "private", next = item.sessions[0], roleCell = isAdmin ? businessState("Protected review", "locked") : businessState(provider ? "Mapping not configured" : "No campaign mapping", "pending");
      return `<tr><td><span class="lc-v4-table-person"><img src="${safe(avatar(item.profile))}" alt="" loading="lazy" decoding="async"><b>${safe(profileName(item.profile))}</b></span></td><td>${businessState(creatorStatus, creatorStatus === "approved" ? "ready" : "pending")}</td><td>${businessState(publication, publication === "published" ? "ready" : "neutral")}</td><td>${roleCell}</td><td>${safe(next ? sessionStatusLabel(next) : "No session")}</td></tr>`;
    }).join(""), liveRows = sessions.slice(0, 12).map(({ item, session }) => `<tr><td>${safe(profileName(item.profile))}</td><td>${safe(session.game || "Not specified")}</td><td>${businessState(sessionStatusLabel(session), isPresentedLive(session) ? "live" : "neutral")}</td><td>${safe(session.operator_name || "Not mapped")}</td><td>${businessState(session.visibility || "private", session.visibility === "public" ? "ready" : "locked")}</td></tr>`).join(""), roleQueue = isAdmin ? `<article><span>01</span><div><b>Moderation decisions</b><p>Visible only to authorized platform roles.</p></div>${businessState("Protected", "locked")}</article><article><span>02</span><div><b>Account enforcement</b><p>Suspension and reinstatement remain server-controlled.</p></div>${businessState("Fail closed", "ready")}</article><article><span>03</span><div><b>Audit trail</b><p>Administrative changes require attributable backend records.</p></div>${businessState("Privileged", "locked")}</article>` : provider ? `<article><span>01</span><div><b>Normalize catalog context</b><p>Define provider-neutral game and table identifiers.</p></div>${businessState("Not configured", "pending")}</article><article><span>02</span><div><b>Map creator identity</b><p>Keep external identity mapping explicit and tenant-scoped.</p></div>${businessState("Not configured", "pending")}</article><article><span>03</span><div><b>Prepare operator delivery</b><p>Validate contracts before any sandbox connection.</p></div>${businessState("No connection", "locked")}</article>` : `<article><span>01</span><div><b>Review creator readiness</b><p>Use only verified, published creator records.</p></div>${businessState("Review required", "pending")}</article><article><span>02</span><div><b>Define campaign source</b><p>Attach campaign context before measuring handoffs.</p></div>${businessState("Not configured", "pending")}</article><article><span>03</span><div><b>Validate handoff route</b><p>Licensed operator destination and return contract are required.</p></div>${businessState("No connection", "locked")}</article>`, overviewCards = isAdmin ? "<article><span>CONTROL SCOPE</span><b>Platform policy</b><p>Tenant access, moderation and audit boundaries.</p></article><article><span>QUEUE</span><b>Private by default</b><p>No moderation item is exposed to business tenants.</p></article><article><span>ACCOUNT STATE</span><b>Server enforced</b><p>Suspended-account denial cannot be overridden here.</p></article>" : provider ? `<article><span>SUPPLY SCOPE</span><b>${safe(recordScope)}</b><p>Creator and Live-product context available to this workspace.</p></article><article><span>ADAPTER STATE</span><b>No live connection</b><p>Credentials and official API contracts are still required.</p></article><article><span>OUTCOME</span><b>To be validated</b><p>No distribution or commercial impact is claimed.</p></article>` : `<article><span>CREATOR SCOPE</span><b>${safe(recordScope)}</b><p>Discovery records do not imply commercial approval.</p></article><article><span>HANDOFF STATE</span><b>No live connection</b><p>No production operator destination is configured.</p></article><article><span>OUTCOME</span><b>To be validated</b><p>CAC, retention, GGR and ROI require observed evidence.</p></article>`, integrationCards = provider ? `<article><header><b>Catalog ingestion</b>${businessState("Not configured", "pending")}</header><p>Normalized games, tables and availability contract.</p><small>Needs official API documentation and tenant credentials.</small></article><article><header><b>Creator identity mapping</b>${businessState("Not configured", "pending")}</header><p>External dealer identity to approved LC Creator record.</p><small>Must fail closed when an identity cannot be verified.</small></article><article><header><b>Operator distribution</b>${businessState("Unavailable", "locked")}</header><p>Tenant-scoped destinations and market availability.</p><small>No operator integration or approval is implied.</small></article><article><header><b>Signed events</b>${businessState("Unavailable", "locked")}</header><p>Webhook signature, idempotency and replay controls.</p><small>Server-side implementation required.</small></article>` : `<article><header><b>Licensed destination</b>${businessState("Not configured", "pending")}</header><p>Allowlisted, server-generated handoff destination.</p><small>Jurisdiction and operator controls remain external.</small></article><article><header><b>Return attribution</b>${businessState("Contract only", "neutral")}</header><p>App-owned intent and attributable return event contract.</p><small>No gameplay or transaction data is collected by LC.</small></article><article><header><b>Campaign source</b>${businessState("Not configured", "pending")}</header><p>Tenant, creator and campaign source context.</p><small>Required before an evidence window can start.</small></article><article><header><b>Event delivery</b>${businessState("Unavailable", "locked")}</header><p>Signed, tenant-scoped server event exchange.</p><small>Credentials and external API documentation required.</small></article>`, views = {
      overview: `<section class="lc-v4-business-hero lc-v4-ops-hero"><div><span>${safe(role.label)}</span><h1>${safe(role.title)}</h1><p>${safe(role.description)}</p></div><div class="lc-v4-ops-hero-status"><small>WORKSPACE ACCESS</small>${businessState(status, isAdmin ? "locked" : "neutral")}</div></section><section class="lc-v4-ops-context" aria-label="Workspace evidence scope">${overviewCards}</section><section class="lc-product-card lc-v4-ops-queue"><div class="lc-product-section-head"><div><small>NEXT ACTIONS</small><h2>${safe(role.focus)}</h2></div><span>${safe(recordScope)}</span></div><div>${roleQueue}</div></section><section class="lc-product-card lc-v4-ops-boundary"><div><span>LC RESPONSIBILITY</span><b>Discovery · creator identity · social signals · handoff intent · attributable return</b></div><div><span>LICENSED INFRASTRUCTURE</span><b>Gameplay · wallet · KYC/AML · wagering · settlement · responsible gaming</b></div></section>`,
      creators: `<section class="lc-v4-business-title"><div><span>${isAdmin ? "IDENTITY CONTROL" : provider ? "IDENTITY MAPPING" : "CREATOR ROSTER"}</span><h1>Creators</h1><p>${isAdmin ? "Inspect protected verification and publication state without changing it from the client." : provider ? "Review approved identity records before mapping external Live-product context." : "Review creator eligibility before campaign or handoff configuration."}</p></div>${businessState(recordScope)}</section><section class="lc-v4-ops-toolbar" aria-label="Creator table controls"><label><span>SEARCH</span><input type="search" placeholder="Search creator" disabled></label><label><span>STATUS</span><select disabled><option>All verification states</option></select></label><button type="button" disabled>Bulk actions unavailable</button></section><section class="lc-product-card lc-v4-table-wrap"><table class="lc-v4-table"><thead><tr><th>Creator</th><th>Verification</th><th>Publication</th><th>${isAdmin ? "Control scope" : provider ? "Provider mapping" : "Campaign mapping"}</th><th>Next session</th></tr></thead><tbody>${creatorRows || '<tr><td colspan="5">No eligible creator records available.</td></tr>'}</tbody></table></section><p class="lc-product-note">Creator verification and affiliation approval remain server-controlled. Demo records are illustrative and do not represent partners or approvals.</p>`,
      campaigns: `<section class="lc-v4-business-title"><div><span>${provider ? "DISTRIBUTION PLAN" : isAdmin ? "POLICY VISIBILITY" : "ACQUISITION PLAN"}</span><h1>Campaigns</h1><p>${isAdmin ? "Campaign records are visible only when authorized policy or audit scope requires them." : provider ? "Define operator, creator and catalog scope before distribution evidence begins." : "Define source, creator and licensed destination before measuring acquisition evidence."}</p></div>${businessState("No active configuration", "pending")}</section>${businessEmpty(isAdmin ? "No campaign audit context" : provider ? "No distribution plan configured" : "No campaign configured", isAdmin ? "Nothing is available in the current protected scope." : "An approved tenant context and measurement brief are required before activation.", "To be validated")}`,
      live: `<section class="lc-v4-business-title"><div><span>${provider ? "DISTRIBUTION MONITOR" : isAdmin ? "SESSION OVERSIGHT" : "LIVE OPERATIONS"}</span><h1>Live</h1><p>${isAdmin ? "Review protected session publication state; LC never controls gameplay." : provider ? "Inspect normalized creator-session context before operator distribution." : "Monitor creator-session readiness and licensed handoff mapping."}</p></div>${businessState(state.demo ? `${liveSessions.length} verified Live · demo records are previews` : `${liveSessions.length} Live`, liveSessions.length ? "live" : "neutral")}</section><section class="lc-v4-ops-toolbar" aria-label="Live table controls"><label><span>SESSION STATE</span><select disabled><option>All states</option></select></label><label><span>MAPPING</span><select disabled><option>All mapping states</option></select></label><button type="button" disabled>Export unavailable</button></section><section class="lc-product-card lc-v4-table-wrap"><table class="lc-v4-table"><thead><tr><th>Creator</th><th>Game</th><th>Status</th><th>Operator mapping</th><th>Visibility</th></tr></thead><tbody>${liveRows || '<tr><td colspan="5">No session data available.</td></tr>'}</tbody></table></section><p class="lc-product-note">Session records describe LC social state only. They do not prove operator availability, gameplay activity or commercial performance.</p>`,
      performance: renderPerformanceWorkspace(subtype, isAdmin),
      integrations: `<section class="lc-v4-business-title"><div><span>${isAdmin ? "PLATFORM CONTROLS" : "CONFIGURATION"}</span><h1>Integrations</h1><p>${isAdmin ? "Inspect integration policy and audit boundaries without exposing credentials." : provider ? "Prepare provider-neutral data contracts for tenant-scoped delivery." : "Prepare a licensed handoff and event contract without moving regulated operations into LC."}</p></div>${businessState("No live connection", "locked")}</section>${isAdmin ? '<section class="lc-v4-safety-grid"><article><h2>Secrets</h2><b>Server only</b><p>No credential or service role is available to this client.</p></article><article><h2>Tenant policy</h2><b>Fail closed</b><p>Cross-tenant reads and writes require protected backend authorization.</p></article><article><h2>Audit delivery</h2><b>Not configured</b><p>No external control-plane integration is claimed.</p></article></section>' : `<section class="lc-v4-integration-grid lc-v4-ops-integrations">${integrationCards}</section>`}`,
      safety: `<section class="lc-v4-business-title"><div><span>TRUST & SAFETY</span><h1>${isAdmin ? "Moderation control" : "Safety & policy"}</h1><p>${isAdmin ? "Protected moderation, account state and audit surfaces remain separate from tenant operations." : "View policy posture for this tenant; moderation records remain private and role-scoped."}</p></div>${businessState("Fail closed", "ready")}</section><section class="lc-v4-safety-grid"><article><h2>Reports</h2><b>${isAdmin ? "Protected moderation queue" : "No queue access"}</b><p>Report ownership and visibility remain isolated by backend policy.</p></article><article><h2>Account status</h2><b>Server-enforced denial</b><p>Suspended accounts cannot continue through this client.</p></article><article><h2>Creator controls</h2><b>No client approval</b><p>Publication and affiliation verification cannot be escalated here.</p></article><article><h2>Audit</h2><b>${isAdmin ? "Privileged scope required" : "Restricted"}</b><p>Administrative actions require an authorized backend role and attributable record.</p></article></section>`,
      settings: `<section class="lc-v4-business-title"><div><span>${isAdmin ? "PLATFORM ACCESS" : "WORKSPACE"}</span><h1>Settings</h1><p>${isAdmin ? "Protected role and environment context." : "Organization, environment and partnership access state."}</p></div>${businessState(status, isAdmin ? "locked" : "neutral")}</section><section class="lc-v4-ops-settings"><article><span>ORGANIZATION</span><h2>${safe(state.industry?.company_name || (state.demo ? "Illustrative organization" : "Company profile not completed"))}</h2><p>${state.demo ? "Demo label only; no real organization, partner or approval is represented." : "Organization details are tenant-scoped."}</p></article><article><span>ENVIRONMENT</span><h2>${state.demo ? "Demonstration" : "Not configured"}</h2><p>No production integration or readiness is implied.</p></article><article><span>ACCESS</span><h2>${status}</h2><p>${isAdmin ? "Admin permissions come from the protected account role, never this view." : "A submission cannot self-approve access or configure an integration."}</p></article></section>${isAdmin ? "" : `<section class="lc-product-card"><button class="lc-product-btn" type="button" data-lc-request-access="${safe(subtype)}">REQUEST PARTNERSHIP ACCESS</button><span class="lc-product-note">Request status remains pending until reviewed by an authorized backend process.</span></section>`}`
    }, selected = Object.prototype.hasOwnProperty.call(views, view) ? view : "overview";
    state.businessView = selected, shell().dataset.lcBusinessView = selected;
    const additions = `${state.demo && ["overview", "campaigns", "integrations"].includes(selected) ? renderLocalBusinessScenario(provider) : ""}${state.demo && ["overview", "performance"].includes(selected) ? renderLocalTrace() : ""}`, firstSectionEnd = views[selected].indexOf("</section>") + 10, renderedView = additions ? views[selected].slice(0, firstSectionEnd) + additions + views[selected].slice(firstSectionEnd) : views[selected];
    shell().innerHTML = `${top(isAdmin ? "LC Control" : provider ? "Provider Back Office" : "Operator Back Office", selected.charAt(0).toUpperCase() + selected.slice(1))}<div class="lc-product-stack lc-v4-business-workspace">${renderedView}</div>`;
  }
  function renderCreatorDetail(id) {
    const item = state.creators.find((entry) => entry.profile.id === id);
    if (!item) return renderMissing("Creator unavailable", "This creator is not available in the current context.", "Back to Discover");
    state.selectedCreator = id, trackProductEvent("creator_profile_open", { creatorId: id, dedupeKey: `profile:${id}` });
    const next = item.sessions[0], isLive = isPresentedLive(next), following = state.follows.has(item.profile.id), gamesLabel = (item.creator.games || []).join(" · ") || "Live Casino", languageLabel = (item.creator.languages || item.profile.languages || []).join(" · ") || "Language not listed", scheduled = item.sessions.filter((session) => session.status === "scheduled");
    shell().innerHTML = `${top(profileName(item.profile), isLive ? sessionStatusLabel(next) : "Creator profile")}
      <div class="lc-product-stack lc-v4-creator-page">
        <section class="lc-v4-creator-hero">
          <img src="${safe(visualImage(item.profile))}" alt="${safe(profileName(item.profile))} at a Live Casino table"><div class="lc-v4-creator-hero-shade"></div>
          <div class="lc-v4-creator-hero-state"><span class="lc-v3-live-pill ${isLive ? "is-live" : ""}">${safe(sessionStatusLabel(next))}</span></div>
          <div class="lc-v4-creator-identity"><img src="${safe(avatar(item.profile))}" alt=""><div><span>${safe(item.profile.username ? "@" + item.profile.username : "CREATOR")}${isIllustrativeProfile(item.profile) ? " · ILLUSTRATIVE PROFILE" : ""}</span><h1>${safe(profileName(item.profile))}</h1><p>${safe(item.creator.headline || "Live Casino creator")}</p></div></div>
        </section>
        <section class="lc-v4-creator-actions"><button class="lc-product-btn ${following ? "secondary active" : ""}" type="button" data-lc-follow="${safe(item.profile.id)}">${following ? "FOLLOWING" : "FOLLOW"}</button>${creatorLiveAlertControl(item.profile.id)}${next ? `<button class="lc-product-btn lc-v4-creator-primary" type="button" data-lc-live="${safe(next.id)}">${isLive ? state.demo ? "OPEN DEMO SESSION" : "JOIN LIVE" : "VIEW SESSION PREVIEW"}</button>` : ""}</section>
        <section class="lc-v4-creator-facts" aria-label="Creator profile activity"><article><b>${item.posts.length}</b><span>Updates</span></article><article><b>${scheduled.length}</b><span>Upcoming</span></article><article><b>${(item.creator.games || []).length}</b><span>Games</span></article></section>
        <section class="lc-v4-creator-about"><div><span>ABOUT</span><h2>${safe(item.profile.bio || item.creator.headline || "Follow this creator to keep their identity, schedule and Live status connected across sessions.")}</h2></div><div class="lc-v4-creator-tags"><span>${safe(gamesLabel)}</span><span>${safe(languageLabel)}</span>${item.profile.country ? `<span>${safe(item.profile.country)}</span>` : ""}<span>${safe(item.creator.affiliation_name || "Affiliation not listed")} · ${safe(item.creator.affiliation_verification_status || "unverified")}</span></div></section>
        ${next ? `<section class="lc-v4-next-live ${isLive ? "is-live" : ""}"><div><span>${safe(sessionStatusLabel(next))}</span><h2>${safe(next.title || "Live session")}</h2><p>${safe(next.game)} · ${safe(sessionLine(next))}</p><small>${safe(next.operator_name || "Operator context not set")} · operator context is not an LC approval</small></div>${isLive ? `<button class="lc-product-btn" type="button" data-lc-live="${safe(next.id)}">${state.demo ? "OPEN DEMO SESSION" : "OPEN LIVE"}</button>` : `<button class="lc-product-btn ${state.reminders.has(next.id) ? "secondary" : ""}" type="button" data-lc-reminder="${safe(next.id)}">${state.reminders.has(next.id) ? "REMINDER SET" : "REMIND ME"}</button>`}</section>` : '<section class="lc-v4-creator-empty"><h2>No session scheduled</h2><p>Follow this creator to keep them in your feed when a new session appears.</p></section>'}
        <section class="lc-v4-creator-content"><div class="lc-v4-social-section-head"><div><span>CONTENT</span><h2>Recent updates</h2></div><b>${item.posts.length}</b></div>${item.posts.length ? `<div class="lc-v4-creator-content-grid">${item.posts.slice(0, 6).map((post) => `<article><img src="${safe(visualImage(item.profile))}" alt="" loading="lazy" decoding="async"><div><time>${safe(dateLabel(post.created_at))}</time><p ${demoPosts.some((seed) => seed.id === post.id) ? "" : "data-lc-user-content"}>${safe(post.body)}</p>${state.demo ? `<button class="lc-product-chip" type="button" data-lc-like="${safe(post.id)}" aria-label="Like post" aria-pressed="${demoStore.likes.has(post.id)}">${demoStore.likes.has(post.id) ? "♥ Liked" : "♡ Like post"}</button><form data-lc-form="comment" data-post-id="${safe(post.id)}"><label for="profile-comment-${safe(post.id)}">Comment on this update</label><input class="lc-product-input" id="profile-comment-${safe(post.id)}" name="body" maxlength="500" required><button class="lc-product-chip" type="submit">Post comment</button></form>${demoStore.comments.filter((comment) => comment.post_id === post.id).map((comment) => `<p><b>You:</b> <span data-lc-user-content>${safe(comment.body)}</span></p>`).join("")}` : ""}</div></article>`).join("")}</div>` : '<div class="lc-v4-creator-empty"><p>No public updates yet.</p></div>'}</section>
        ${scheduled.length > (isLive ? 0 : 1) ? `<section class="lc-v4-creator-schedule"><div class="lc-v4-social-section-head"><div><span>SCHEDULE</span><h2>More return moments</h2></div></div>${scheduled.filter((session) => session.id !== next?.id).map((session) => `<article><div><span>${safe(session.game)}</span><b>${safe(session.title || "Live session")}</b><small>${safe(sessionLine(session))}</small></div><button class="lc-product-chip ${state.reminders.has(session.id) ? "active" : ""}" type="button" data-lc-reminder="${safe(session.id)}">${state.reminders.has(session.id) ? "Saved" : "Remind me"}</button></article>`).join("")}</section>` : ""}
        <section class="lc-v4-creator-safety" aria-label="Creator safety actions"><span>Keep your experience safe</span><div><button type="button" data-lc-creator-safety="report" data-lc-creator-id="${safe(id)}">Report</button><button type="button" data-lc-creator-safety="block" data-lc-creator-id="${safe(id)}">Block</button></div></section>
      </div>${tabs("explore")}`;
  }
  function renderCreatorSafety(id, mode) {
    const item = state.creators.find((entry) => entry.profile.id === id);
    if (!item) return renderMissing("Creator unavailable", "This Creator is no longer available in discovery.", "Back to Discover");
    const name = profileName(item.profile), report = mode === "report";
    shell().innerHTML = `${top(report ? "Report Creator" : "Block Creator", "Safety control")}
      <div class="lc-product-stack">
        <section class="lc-product-card"><div class="lc-product-row"><img src="${safe(avatar(item.profile))}" alt=""><div class="lc-product-row-main"><b>${safe(name)}</b><span>${safe(item.profile.username ? "@" + item.profile.username : "Creator profile")}</span></div></div></section>
        ${report ? `<form class="lc-product-card lc-product-form" data-lc-form="creator-report" data-lc-creator-id="${safe(id)}"><h2>Why are you reporting this profile?</h2><select class="lc-product-select" name="reason" ${state.demo ? "disabled" : ""}>${reportReasons.map(([value, label]) => `<option value="${safe(value)}">${safe(label)}</option>`).join("")}</select><textarea class="lc-product-textarea" name="description" maxlength="500" placeholder="Optional context for the moderation team" ${state.demo ? "disabled" : ""}></textarea><span class="lc-product-note">${state.demo ? "Preview only. Sign in to send a private report; no report is created here." : "Your report is private. Submission does not automatically remove or penalize the profile."}</span><div class="lc-product-actions"><button class="lc-product-btn" type="submit" ${state.demo ? "disabled" : ""}>${state.demo ? "SIGN IN REQUIRED" : "SUBMIT REPORT"}</button><button class="lc-product-chip" type="button" data-lc-open-creator="${safe(id)}">Cancel</button></div></form>` : `<section class="lc-product-card"><h2>Remove ${safe(name)} from your experience?</h2><p>You will no longer see this Creator in LC discovery. New follow interactions between your accounts will be denied while the block is active.</p><span class="lc-product-note">${state.demo ? "Preview only. Sign in to create a private block; the demo does not change any account." : "Blocking is private and can be reversed from Profile → Safety center."}</span><div class="lc-product-actions"><button class="lc-product-btn" type="button" data-lc-confirm-block="${safe(id)}" ${state.demo ? "disabled" : ""}>${state.demo ? "SIGN IN REQUIRED" : "BLOCK CREATOR"}</button><button class="lc-product-chip" type="button" data-lc-open-creator="${safe(id)}">Cancel</button></div></section>`}
      </div>${tabs("explore")}`;
  }
  function renderSocialSafety() {
    const status = "Illustrative active state";
    shell().innerHTML = `${top("Safety center", "Private controls and account boundaries")}
      <div class="lc-product-stack lc-v4-safety-center">
        <section class="lc-v4-safety-hero"><span class="lc-v3-kicker">TRUST & SAFETY</span><h1>You control who reaches your social experience.</h1><p>Reports, blocks, notification preferences and account access remain private and isolated from business workspaces.</p></section>
        <section class="lc-v4-safety-cards">
          <article><span>ACCOUNT STATUS</span><b>${safe(status)}</b><p>Access is enforced by the backend. A suspended or disabled account cannot continue into LC.</p></article>
          <article><span>REPORTS</span><b>Private submission</b><p>A report does not automatically remove or penalize a Creator. Moderation visibility remains role-scoped.</p></article>
          <article><span>BLOCKING</span><b>Relationship boundary</b><p>Blocked profiles leave discovery, and new follow or return interactions are denied.</p></article>
          <article><span>BUSINESS ACCESS</span><b>Separated</b><p>Operator and Provider tenants cannot read personal reports, blocks or notification settings.</p></article>
        </section>
        <section class="lc-v4-profile-controls"><div class="lc-v4-social-section-head"><div><span>YOUR CONTROLS</span><h2>Privacy and signals</h2></div></div><div class="lc-v4-settings-list">
          <button type="button" disabled><span><b>Live creator signals</b><small>Preview only · in-app delivery</small></span><i>○</i></button><button type="button" disabled><span><b>Blocked creators</b><small>Sign in to manage private blocks</small></span><i>›</i></button><div class="lc-private-unavailable" role="note"><b>Private account settings</b><p>Unavailable in the public demo. Password, privacy and deletion require the separate authenticated product.</p></div>
        </div></section>
        <button class="lc-product-btn secondary" type="button" data-lc-product="profile">BACK TO PROFILE</button>
      </div>${tabs("profile")}`;
  }
  function renderBlockedCreators() {
    shell().innerHTML = `${top("Blocked Creators", "Account safety")}
      <div class="lc-product-stack">
        <section class="lc-product-card"><div class="lc-product-section-head"><h2>Blocked profiles</h2><span>${state.blockedIds.size}</span></div><p>Blocked Creators are removed from discovery and cannot start new follow interactions with your account.</p></section>
        <section class="lc-product-card">${state.blockedProfiles.length ? state.blockedProfiles.map((profile) => `<div class="lc-product-row"><img src="${safe(avatar(profile))}" alt=""><div class="lc-product-row-main"><b>${safe(profileName(profile))}</b><span>${safe(profile.username ? "@" + profile.username : "Blocked profile")}</span></div><button class="lc-product-chip" type="button" data-lc-unblock="${safe(profile.id)}">Unblock</button></div>`).join("") : '<div class="lc-product-empty">No blocked Creators.</div>'}</section>
        <button class="lc-product-btn secondary" type="button" data-lc-product="account">BACK TO ACCOUNT</button>
      </div>${tabs("profile")}`;
  }
  function renderLive(sessionId) {
    const found = findSessionEntry(sessionId), item = found?.entry, session = found?.session;
    if (!item || !session) return renderMissing("Session unavailable", "This Live context is no longer available.", "Back to Discover");
    state.selectedCreator = item.profile.id, state.selectedSession = session.id, session.status === "live" && !state.demo && !state.handoffDestinations.has(session.id) && resolveHandoffDestination(session), session.status === "live" && trackProductEvent("live_session_open", { creatorId: item.profile.id, sessionId: session.id, dedupeKey: `live:${session.id}` });
    const isLive = isPresentedLive(session), preview = isSessionPreview(session), destination = state.handoffDestinations.get(session.id), following = state.follows.has(item.profile.id), primaryAction = preview ? '<button class="lc-product-btn lc-v4-live-primary" type="button" data-lc-product="handoff">PREVIEW HANDOFF</button>' : isLive && destination?.state === "available" ? '<button class="lc-product-btn lc-v4-live-primary" type="button" data-lc-product="handoff">CONTINUE TO LICENSED OPERATOR</button>' : isLive && destination?.state === "loading" ? '<button class="lc-product-btn lc-v4-live-primary" type="button" disabled>CHECKING OPERATOR DESTINATION</button>' : isLive ? '<button class="lc-product-btn lc-v4-live-primary" type="button" disabled>OPERATOR DESTINATION UNAVAILABLE</button>' : `<button class="lc-product-btn lc-v4-live-primary ${state.reminders.has(session.id) ? "secondary" : ""}" type="button" data-lc-reminder="${safe(session.id)}">${state.reminders.has(session.id) ? "REMINDER SET" : "REMIND ME WHEN IT STARTS"}</button>`;
    shell().innerHTML = `${top(sessionStatusLabel(session), profileName(item.profile))}
      <div class="lc-product-stack lc-v4-live-page ${state.demo ? "lc-demo-room" : ""}">
        <section class="lc-v4-live-stage"><img src="${safe(visualImage(item.profile))}" alt="${safe(profileName(item.profile))} Live session"><div class="lc-v4-live-stage-shade"></div><div class="lc-v4-live-stage-top"><span class="lc-v3-live-pill ${isLive ? "is-live" : ""}">${safe(sessionStatusLabel(session))}</span><span>${safe(session.game)}</span></div><div class="lc-v4-live-identity"><img src="${safe(avatar(item.profile))}" alt=""><div><span>${safe(session.title || "Live table session")}</span><h1>${safe(profileName(item.profile))}</h1><p>${safe(dateLabel(session.starts_at))}</p></div></div></section>
        ${renderDemoTable(session)}
        <section class="lc-v4-live-actions">${primaryAction}<button class="lc-product-btn secondary ${following ? "active" : ""}" type="button" data-lc-follow="${safe(item.profile.id)}">${following ? "FOLLOWING" : "FOLLOW CREATOR"}</button></section>
        <section class="lc-v4-live-context"><div><span>CREATOR CONTEXT</span><b>${safe(profileName(item.profile))} · ${safe(session.game)}</b><p>Follow and return context stays in LC.</p></div><div><span>OPERATOR CONTEXT</span><b>${safe(session.operator_name || "Not configured")}</b><p>This label is not proof of integration, approval or availability.</p></div></section>
        <section class="lc-v4-live-boundary"><b>LC connects the person to the Live moment.</b><p>The licensed operator remains responsible for gameplay, wallet, KYC/AML, wagering, settlement and responsible-gaming operations.</p></section>
        <button class="lc-v4-journey-back" type="button" data-lc-open-creator="${safe(item.profile.id)}">← Back to ${safe(profileName(item.profile))}</button>
      </div>${tabs("explore")}`;
  }
  function renderHandoff(sessionId = state.selectedSession) {
    const found = findSessionEntry(sessionId);
    if (!found) return renderMissing("Handoff unavailable", "The selected table context is not available.", "Back to Discover");
    const { entry, session } = found, preview = isSessionPreview(session), destination = state.handoffDestinations.get(session.id);
    if (!preview && !isPresentedLive(session)) return renderMissing("Session not Live", "Operator handoff becomes available when this Creator session is Live.", "Back to Discover");
    if (!preview && destination?.state !== "available") return renderMissing("Handoff unavailable", "No approved operator destination is available for this session.", "Back to Live");
    state.selectedCreator = entry.profile.id, state.selectedSession = session.id, trackProductEvent("product_open", { creatorId: entry.profile.id, sessionId: session.id, dedupeKey: `handoff-view:${session.id}`, metadata: { surface: "handoff" } }), shell().innerHTML = `${top(preview ? "Preview handoff" : "Continue to operator", `${session.game} with ${profileName(entry.profile)}`)}
      <div class="lc-product-stack lc-v4-handoff-page">
        <section class="lc-v4-handoff-hero"><img src="${safe(visualImage(entry.profile))}" alt=""><div><span>${preview ? "ILLUSTRATIVE HANDOFF PREVIEW" : "LEAVING LC APP"}</span><h1>${preview ? "Preview the licensed-operator handoff." : "Continue with the licensed operator."}</h1><p>${safe(profileName(entry.profile))} · ${safe(session.game)}</p></div></section>
        <section class="lc-v4-handoff-steps" aria-label="Handoff boundaries"><article><span>01</span><div><b>Your session context stays connected</b><p>LC keeps the Creator and session linked to your return journey.</p></div></article><article><span>02</span><div><b>The operator owns play</b><p>Gameplay, account, funds, KYC/AML and responsible-gaming controls remain external.</p></div></article><article><span>03</span><div><b>You can return to the person</b><p>Follow state, content and future Live signals remain connected to this Creator.</p></div></article></section>
        <section class="lc-v4-handoff-destination"><div><span>DESTINATION</span><h2>${safe(preview ? session.operator_name || "Illustrative operator" : destination.label)}</h2><p>${preview ? "Illustrative demo label only. No external destination is configured." : "Approved HTTPS operator destination resolved by the server."}</p></div>${preview ? `<button class="lc-product-btn lc-v4-live-primary" type="button" data-lc-return-live="${safe(session.id)}">SIMULATE OPERATOR RETURN</button>` : `<button class="lc-product-btn lc-v4-live-primary" type="button" data-lc-operator-outbound="${safe(session.id)}">CONTINUE TO LICENSED OPERATOR</button>`}</section>
        <p class="lc-v4-handoff-disclosure">${preview ? "Demo flow only. No operator integration, license, approval or production availability is claimed." : "Navigation is available only for a server-resolved, approved HTTPS destination. LC does not handle regulated gameplay."}</p>
        <button class="lc-v4-journey-back" type="button" data-lc-live="${safe(session.id)}">← Back to Live</button>
      </div>${tabs("explore")}`;
  }
  function renderMissing(title, body, action) {
    shell().innerHTML = `${top(title, "Product state")}
      <div class="lc-product-stack">
        <section class="lc-product-card lc-product-empty"><h2>${safe(title)}</h2><p>${safe(body)}</p><div class="lc-product-actions"><button class="lc-product-btn" type="button" data-lc-product="discover">${safe(action || "Back to Discover")}</button></div></section>
      </div>${tabs("explore")}`;
  }
  function renderAccount() {
    const persona = state.current?.persona || "none", isCreator = persona === "creator", ownPosts = isCreator ? state.posts.filter((post) => !post.deleted_at && post.status !== "deleted") : [], upcoming = isCreator ? state.sessions.filter((session) => session.status === "scheduled") : savedScheduleEntries(), profileStatus = isCreator ? creatorPublication() : null;
    shell().innerHTML = `${top("Profile", isCreator ? "Your public identity and controls" : "Your social corner")}
      <div class="lc-product-stack lc-v4-social-profile">
        <section class="lc-v4-profile-hero"><div class="lc-v4-profile-avatar"><img src="${safe(avatar(state.profile))}" alt=""><span>${isCreator && profileStatus?.publicReady ? "CREATOR" : "LC"}</span></div><div class="lc-v4-profile-identity"><span class="lc-v3-kicker">${isCreator ? "CREATOR PROFILE" : "PLAYER PROFILE"}</span><h1>${safe(profileName(state.profile))}</h1><p>${safe(state.profile.username ? "@" + state.profile.username : "LC App member")}${state.profile.bio ? ` · ${safe(state.profile.bio)}` : ""}</p></div>${isCreator ? '<button class="lc-product-btn" type="button" data-lc-product="create">OPEN STUDIO</button>' : '<button class="lc-product-chip" type="button" data-lc-product="explore">DISCOVER</button>'}</section>
        <section class="lc-v4-profile-stats" aria-label="App-owned profile activity"><button type="button" data-lc-product="explore"><b>${state.follows.size}</b><span>Following</span></button><button type="button" data-lc-product="activity"><b>${upcoming.length}</b><span>${isCreator ? "Scheduled" : "Saved"}</span></button><button type="button" ${isCreator ? 'data-lc-product="create"' : 'data-lc-product="activity"'}><b>${isCreator ? ownPosts.length : state.notifications.length}</b><span>${isCreator ? "Posts" : "Signals"}</span></button></section>
        ${isCreator ? `<section class="lc-v4-profile-public"><div class="lc-v4-social-section-head"><div><span>PUBLIC PROFILE</span><h2>${safe(state.creator?.headline || "Live Casino creator")}</h2></div><b>${safe(profileStatus?.publicReady ? "Live" : "Private")}</b></div><p>${safe(state.profile.bio || "Add a short bio from secure profile settings.")}</p><div class="lc-v4-profile-tags">${[...state.creator?.games || [], ...state.creator?.languages || []].map((item) => `<span>${safe(item)}</span>`).join("")}</div>${ownPosts.length ? `<div class="lc-v4-profile-media-grid">${ownPosts.slice(0, 6).map((post, index) => `<button type="button" data-lc-product="create"><img src="${safe(visualImage(state.profile))}" alt=""><span>${safe(post.body)}</span><i>${String(index + 1).padStart(2, "0")}</i></button>`).join("")}</div>` : '<div class="lc-v4-inline-empty"><p>No published posts yet. Create your first social update in Studio.</p><button class="lc-product-chip" type="button" data-lc-product="create">CREATE A POST</button></div>'}</section>` : ""}
        ${persona === "player" && state.player ? `<section class="lc-v4-profile-preferences"><div class="lc-v4-social-section-head"><div><span>YOUR FEED</span><h2>Discovery preferences</h2></div></div><div><article><small>GAMES</small><p>${safe((state.player.favorite_games || []).join(" · ") || "Not set")}</p></article><article><small>LANGUAGES</small><p>${safe((state.player.preferred_languages || []).join(" · ") || "Not set")}</p></article></div></section>` : ""}
        <section class="lc-v4-profile-controls"><div class="lc-v4-social-section-head"><div><span>ACCOUNT</span><h2>Settings and safety</h2></div></div>
          <div class="lc-v4-settings-list">
            <button type="button" data-lc-safety-center><span><b>Safety center</b><small>Reports, blocks, signals and account state</small></span><i>›</i></button>
            
            <div class="lc-v4-account-boundary"><span><b>Account security role</b><small>Separate from the product experience</small></span><em>${safe(state.profile.role || "user")}</em></div>
          </div>
        </section>
        <section class="lc-v4-profile-mode"><div><span class="lc-v3-kicker">EXPERIENCE</span><h2>Use LC as</h2><p>Switching product mode never changes permissions or account role.</p></div><div class="lc-v4-mode-switch"><button class="${persona === "player" ? "active" : ""}" type="button" data-lc-persona="player">Player</button><button class="${persona === "creator" ? "active" : ""}" type="button" data-lc-persona="creator">Creator</button><button class="${persona === "industry" ? "active" : ""}" type="button" data-lc-persona="industry">Business</button></div></section>
        <section class="lc-v4-profile-signout"><button class="lc-product-chip" type="button" data-lc-demo-exit>BACK TO OPENING</button><p>LC never holds gameplay funds, wallet data, wagering or KYC/AML records.</p></section>
      </div>${tabs("profile")}`;
  }
  async function toggleLiveSignals() {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  function routeHome() {
    return state.current ? state.current.persona === "player" && !state.player?.onboarding_completed ? renderPlayerOnboarding() : state.current.persona === "creator" && !state.creator?.onboarding_completed ? renderCreatorOnboarding() : ["player", "creator"].includes(state.current.persona) ? state.socialView === "explore" ? renderSocialExplore() : state.socialView === "create" ? renderSocialCreate() : state.socialView === "activity" ? renderSocialActivity() : state.socialView === "profile" ? renderAccount() : renderPlayerHome() : state.current.persona === "industry" ? state.industry?.onboarding_completed ? renderIndustryHome(state.businessView) : renderIndustryOnboarding() : renderPersonaChoice() : renderPersonaChoice();
  }
  async function savePlayer(form) {
    const favorite_games = values(form, "games"), preferred_languages = values(form, "languages");
    if (!favorite_games.length || !preferred_languages.length) throw new Error("validation");
    state.player = { user_id: state.profile.id, favorite_games, preferred_languages, onboarding_completed: !0 };
  }
  async function saveCreator(form) {
    const data = new FormData(form), headline = String(data.get("headline") || "").trim().slice(0, 120), bio = String(data.get("bio") || "").trim().slice(0, 280), selectedGames = values(form, "games"), selectedLanguages = values(form, "languages");
    if (!headline || !selectedGames.length || !selectedLanguages.length) throw new Error("validation");
    state.creator = { ...state.creator, headline, games: selectedGames, languages: selectedLanguages, affiliation_type: String(data.get("affiliation_type") || "unlisted"), affiliation_name: String(data.get("affiliation_name") || "").trim().slice(0, 120) || null, profile_status: "published", onboarding_completed: !0 };
  }
  async function saveIndustry(form) {
    const data = new FormData(form), subtype = state.current?.industry_subtype || "operator", payload = {
      user_id: state.profile.id,
      subtype,
      company_name: String(data.get("company_name") || "").trim().slice(0, 120),
      job_title: String(data.get("job_title") || "").trim().slice(0, 120),
      work_email: String(data.get("work_email") || "").trim().slice(0, 254),
      website_url: String(data.get("website_url") || "").trim().slice(0, 300) || null,
      interests: values(form, "interests"),
      onboarding_completed: !0
    };
    if (!payload.company_name || !payload.job_title || !payload.work_email.includes("@")) throw new Error("validation");
    state.industry = { ...state.industry, ...payload, onboarding_completed: !0 };
  }
  async function savePilotBrief(form, shouldSubmit = !1) {
    const data = new FormData(form), subtype = state.industry?.subtype || state.current?.industry_subtype || "operator", hypothesis = String(data.get("primary_hypothesis") || ""), observedEvents = values(form, "observed_events"), attributionWindowDays = Number(data.get("attribution_window_days")), feedReadiness = String(data.get("feed_readiness") || "not_available"), handoffReadiness = String(data.get("handoff_readiness") || "not_available"), existing = state.pilotBriefs.find((row) => row.industry_subtype === subtype);
    if (!PILOT_HYPOTHESES.some(([value]) => value === hypothesis) || !observedEvents.length || observedEvents.some((value) => !PILOT_EVENTS.some(([eventName]) => eventName === value)) || !Number.isInteger(attributionWindowDays) || attributionWindowDays < 1 || attributionWindowDays > 30 || !["not_available", "documentation_available", "sandbox_available"].includes(feedReadiness) || !["not_available", "conceptual", "sandbox_available"].includes(handoffReadiness) || existing && existing.status !== "draft") throw new Error("validation");
    const payload = {
      user_id: state.profile.id,
      industry_subtype: subtype,
      primary_hypothesis: hypothesis,
      attribution_window_days: attributionWindowDays,
      observed_events: observedEvents,
      feed_readiness: feedReadiness,
      handoff_readiness: handoffReadiness,
      notes: String(data.get("notes") || "").trim().slice(0, 1e3) || null,
      status: "draft"
    };
    {
      const row = { ...existing, ...payload, id: existing?.id || `demo-pilot-${Date.now()}`, status: shouldSubmit ? "submitted" : "draft", updated_at: (/* @__PURE__ */ new Date()).toISOString() };
      demoStore.pilotBriefs = [...demoStore.pilotBriefs.filter((item) => item.industry_subtype !== subtype), row], state.pilotBriefs = [...demoStore.pilotBriefs];
      return;
    }
  }
  async function createPost(form) {
    const body = String(new FormData(form).get("body") || "").trim();
    if (!body) throw new Error("validation");
    demoStore.posts.unshift({ id: `demo-post-${Date.now()}`, author_id: state.profile.id, body, created_at: (/* @__PURE__ */ new Date()).toISOString(), status: "active", deleted_at: null });
  }
  async function createSession(form) {
    const data = new FormData(form), starts = String(data.get("starts_at") || "");
    if (!starts || !Number.isFinite(new Date(starts).getTime()) || new Date(starts).getTime() <= Date.now()) throw new Error("validation");
    demoStore.sessions.unshift({
      id: `demo-session-${Date.now()}`,
      creator_id: state.profile.id,
      title: String(data.get("title") || "").trim().slice(0, 120) || "Live session",
      game: String(data.get("game") || "Blackjack"),
      operator_name: String(data.get("operator_name") || "").trim().slice(0, 120) || "Demo Casino",
      starts_at: new Date(starts).toISOString(),
      status: "scheduled",
      visibility: "public",
      provenance: "illustrative_demo_data"
    });
  }
  async function submitCreatorReport(form) {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  async function blockCreator(id) {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  async function unblockCreator(id) {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  async function setCreatorProfileStatus(profileStatus) {
    if (!state.creator || !["draft", "published"].includes(profileStatus)) throw new Error("validation");
    state.creator = { ...state.creator, profile_status: profileStatus };
  }
  async function updateCreatorSession(id, changes) {
    const session = state.sessions.find((row) => row.id === id);
    if (!session) throw new Error("validation");
    const allowedTransitions = {
      scheduled: /* @__PURE__ */ new Set(["scheduled", "live", "cancelled"]),
      live: /* @__PURE__ */ new Set(["live", "completed", "cancelled"]),
      completed: /* @__PURE__ */ new Set(["completed"]),
      cancelled: /* @__PURE__ */ new Set(["cancelled"])
    };
    if (changes.status && !allowedTransitions[session.status]?.has(changes.status)) throw new Error("invalid_transition");
    if (changes.status === "live" && state.sessions.some((row) => row.id !== id && row.status === "live")) throw new Error("already_live");
    if (changes.visibility === "public" && !creatorPublication().publicReady) throw new Error("not_verified");
    if (changes.status === "live" && session.visibility !== "public") throw new Error("publish_first");
    const nextChanges = ["completed", "cancelled"].includes(changes.status) ? { ...changes, visibility: "private" } : changes;
    demoStore.sessionOverrides.set(id, { ...demoStore.sessionOverrides.get(id) || {}, ...nextChanges }), refreshDemoData();
  }
  async function toggleFollow(id) {
    const wasFollowing = state.follows.has(id), liveAlertsWereEnabled = state.creatorLiveAlerts.get(id) !== !1;
    if (wasFollowing) {
      state.follows.delete(id), state.creatorLiveAlerts.delete(id), demoStore.follows.delete(id), demoStore.creatorLiveAlerts.delete(id);
      return;
    } else {
      state.follows.add(id), state.creatorLiveAlerts.set(id, !0), demoStore.follows.add(id), demoStore.creatorLiveAlerts.set(id, !0);
      return;
    }
    !wasFollowing && state.follows.has(id) && trackProductEvent("creator_follow", { creatorId: id, metadata: { action: "follow" } });
  }
  async function toggleCreatorLiveAlerts(id) {
    if (!state.follows.has(id) || !state.liveSignalsEnabled) throw new Error("not_eligible");
    const enabled = state.creatorLiveAlerts.get(id) === !1;
    state.creatorLiveAlerts.set(id, enabled), demoStore.creatorLiveAlerts.set(id, enabled);
  }
  async function toggleReminder(id) {
    const wasSet = state.reminders.has(id), found = findSessionEntry(id);
    if (!wasSet && (!found || found.session.status !== "scheduled" || new Date(found.session.starts_at).getTime() <= productNow())) throw new Error("not_eligible");
    if (wasSet) {
      state.reminders.delete(id), demoStore.reminders.delete(id);
      return;
    } else {
      state.reminders.add(id), demoStore.reminders.add(id);
      return;
    }
    !wasSet && state.reminders.has(id) && trackProductEvent("schedule_reminder", { creatorId: found?.entry.profile.id, sessionId: id, metadata: { action: "set" } });
  }
  async function likePost(id) {
    demoStore.likes.has(id) ? demoStore.likes.delete(id) : demoStore.likes.add(id), q(".lc-v4-creator-page") && state.selectedCreator ? renderCreatorDetail(state.selectedCreator) : renderPlayerHome(), toast("Demo reaction updated");
  }
  async function commentPost(form) {
    const body = String(new FormData(form).get("body") || "").trim(), postId = form.dataset.postId;
    if (!body || body.length > 500 || !postId) throw new Error("validation");
    demoStore.comments.push({ post_id: postId, body, created_at: (/* @__PURE__ */ new Date()).toISOString() }), form.reset(), toast("Demo comment saved");
  }
  async function requestAccess(subtype) {
    demoStore.requests.add(subtype), state.accessRequests = [...demoStore.requests].map((industry_subtype) => ({ industry_subtype, status: "submitted", created_at: (/* @__PURE__ */ new Date()).toISOString() })), toast("Demo request saved");
  }
  async function handleSubmit(event) {
    const localForm = event.target.closest?.('[data-lc-form="demo-campaign"], [data-lc-form="demo-mapping"]');
    if (localForm && state.demo) {
      event.preventDefault();
      const value = String(new FormData(localForm).get("context") || "").trim().slice(0, 80);
      if (!value) return;
      const mapping = localForm.dataset.lcForm === "demo-mapping";
      demoStore[mapping ? "mapping" : "campaign"] = value, demoStore.trace.push({ name: mapping ? "local_mapping_draft" : "local_campaign_draft", creator: "demo-sofia", at: Date.now() }), renderIndustryHome(state.businessView);
      return;
    }
    const form = event.target.closest("[data-lc-form]");
    if (!form || state.busy) return;
    event.preventDefault();
    const button = form.querySelector("button[type='submit']");
    setBusy(button, !0);
    try {
      const type = form.dataset.lcForm;
      if (type === "room-chat" && state.demo) {
        const body = String(new FormData(form).get("body") || "").trim().slice(0, 240), id = form.dataset.sessionId;
        if (!body || !findSessionEntry(id)) throw new Error("validation");
        const messages = demoStore.roomMessages.get(id) || [];
        demoStore.roomMessages.set(id, [...messages, body].slice(-20)), refreshDemoRoom(id);
        return;
      }
      if (type === "player" && await savePlayer(form), type === "creator" && await saveCreator(form), type === "industry" && await saveIndustry(form), type === "pilot-brief" && await savePilotBrief(form, event.submitter?.value === "submit"), type === "post" && await createPost(form), type === "session" && await createSession(form), type === "creator-report") {
        await submitCreatorReport(form), await loadState(), routeHome(), toast(state.demo ? "Demo report saved locally" : "Report submitted privately");
        return;
      }
      const commentScroll = type === "comment" && state.demo ? q("#lcProductShell")?.scrollTop : null;
      if (type === "comment" && await commentPost(form), type === "search") {
        state.search = String(new FormData(form).get("search") || "").trim().slice(0, 80), trackProductEvent("discovery_search", { metadata: { has_query: !!state.search, result_count: suggestedCreators().length } }), state.socialView = "explore", renderSocialExplore();
        return;
      }
      if (state.demo) {
        refreshDemoData(), type === "comment" && q(".lc-v4-creator-page") && state.selectedCreator ? renderCreatorDetail(state.selectedCreator) : routeHome(), commentScroll !== null && (q("#lcProductShell").scrollTop = commentScroll), toast("Demo action saved");
        return;
      }
      await loadState(), routeHome(), toast("Saved");
    } catch (error) {
      if (error.message === "validation" && state.demo && investorMode && ["comment", "room-chat"].includes(form.dataset.lcForm)) {
        const field = form.querySelector('[name="body"]');
        field && (field.setCustomValidity("Enter a message within the displayed length limit."), field.reportValidity(), field.addEventListener("input", () => field.setCustomValidity(""), { once: !0 }));
      }
      toast(error.message === "validation" ? "Check the required fields." : err(error));
    } finally {
      setBusy(button, !1);
    }
  }
  async function navigateProduct(value) {
    try {
      return state.demo && investorMode && /\/(creator|live|handoff)\//.test(window.location.hash) && window.history.replaceState(null, "", `#/product/demo/${state.demoPersona}`), state.selectedCreator = null, state.selectedSession = null, ["overview", "creators", "campaigns", "live", "performance", "integrations", "safety", "settings"].includes(value) ? (state.businessView = value, renderIndustryHome(value)) : ["profile", "account"].includes(value) ? (state.socialView = "profile", renderAccount()) : ["explore", "discover"].includes(value) ? (await loadCreators(), state.socialView = "explore", renderSocialExplore()) : ["create", "creator"].includes(value) ? (state.socialView = "create", renderSocialCreate()) : value === "activity" ? (state.socialView = "activity", renderSocialActivity()) : value === "home" ? (state.socialView = "home", renderPlayerHome()) : routeHome();
    } finally {
      window.requestAnimationFrame(() => {
        const heading = q("#lcProductShell h1") || q("#lcProductShell h2");
        heading && (heading.setAttribute("tabindex", "-1"), heading.focus({ preventScroll: !0 }));
      });
    }
  }
  async function handleClick(event) {
    const target = event.target, tour = target.closest("[data-lc-tour-step], [data-lc-tour-action], [data-lc-tour-next], [data-lc-tour-skip], [data-lc-tour-restart]");
    if (tour && investorMode && state.demo) {
      if (event.preventDefault(), tour.hasAttribute("data-lc-tour-skip") ? tourStep = -1 : tour.hasAttribute("data-lc-tour-restart") ? (tourStep = 0, setupDemo("player", !0)) : tour.hasAttribute("data-lc-tour-step") ? tourStep = Number(tour.dataset.lcTourStep) : tour.hasAttribute("data-lc-tour-next") && (tourStep = tourStep === 2 ? -1 : tourStep + 1), tour.hasAttribute("data-lc-tour-action")) {
        if (tourStep === 0)
          return state.search = "", navigateProduct("explore");
        if (tourStep === 1)
          return setupDemo("player", !1), setProductHash(["demo", "player", "creator", "demo-sofia"]) ? void 0 : renderCreatorDetail("demo-sofia");
        if (tourStep === 2) return enterDemo("operator");
      }
      return tour.hasAttribute("data-lc-tour-restart") && setProductHash(["demo", "player"]) ? void 0 : renderProductTarget(productParts().slice(2));
    }
    const gameChoice = target.closest("[data-lc-demo-game]");
    if (gameChoice && state.demo)
      return event.preventDefault(), state.search = gameChoice.dataset.lcDemoGame, state.discoveryFilter = "for_you", navigateProduct("explore");
    const demoRound = target.closest("[data-lc-demo-round]");
    if (demoRound && state.demo) {
      event.preventDefault();
      const id = demoRound.dataset.lcDemoRound;
      return demoStore.roomRounds.set(id, (demoStore.roomRounds.get(id) || 0) + 1), refreshDemoRoom(id);
    }
    const demoReact = target.closest("[data-lc-demo-react]");
    if (demoReact && state.demo) {
      event.preventDefault();
      const id = demoReact.dataset.lcDemoReact;
      return demoStore.roomReactions.has(id) ? demoStore.roomReactions.delete(id) : demoStore.roomReactions.add(id), refreshDemoRoom(id);
    }
    const persona = target.closest("button[data-lc-persona], [role='button'][data-lc-persona]"), industry = target.closest("[data-lc-industry]"), nav = target.closest("[data-lc-product]"), openCreator = target.closest("[data-lc-open-creator]"), live = target.closest("[data-lc-live]"), follow = target.closest("[data-lc-follow]"), creatorLiveAlerts = target.closest("[data-lc-creator-live-alerts]"), reminder = target.closest("[data-lc-reminder]"), like = target.closest("[data-lc-like]"), access = target.closest("[data-lc-request-access]"), demoPersona = target.closest("[data-lc-demo-persona]"), demoExit = target.closest("[data-lc-demo-exit]"), demoReset = target.closest("[data-lc-demo-reset]"), demoSwitch = target.closest("[data-lc-demo-switch]"), returnLive = target.closest("[data-lc-return-live]"), operatorOutbound = target.closest("[data-lc-operator-outbound]"), clearSearch = target.closest("[data-lc-clear-search]"), retry = target.closest("[data-lc-retry]"), notification = target.closest("[data-lc-notification]"), notificationsRead = target.closest("[data-lc-notifications-read]"), creatorProfileStatus = target.closest("[data-lc-creator-profile-status]"), sessionVisibility = target.closest("[data-lc-session-visibility]"), sessionStatus = target.closest("[data-lc-session-status]"), creatorSafety = target.closest("[data-lc-creator-safety]"), safetyCenter = target.closest("[data-lc-safety-center]"), confirmBlock = target.closest("[data-lc-confirm-block]"), blockedList = target.closest("[data-lc-blocked-list]"), unblock = target.closest("[data-lc-unblock]"), liveSignals = target.closest("[data-lc-live-signals]"), discoveryFilter = target.closest("[data-lc-discovery-filter]"), homeFilter = target.closest("[data-lc-home-filter]"), creatorStudio = target.closest("[data-lc-creator-studio]"), businessView = target.closest("button[data-lc-business-view]");
    try {
      if (creatorStudio) {
        event.preventDefault();
        const value = creatorStudio.dataset.lcCreatorStudio;
        if (!["overview", "post", "schedule", "live", "audience"].includes(value)) return;
        state.creatorStudioView = value, state.socialView = "create", renderCreatorHome();
        return;
      }
      if (homeFilter) {
        event.preventDefault();
        const value = homeFilter.dataset.lcHomeFilter;
        if (!["for_you", "following"].includes(value)) return;
        state.discoveryFilter = value, state.socialView = "home", trackProductEvent("discovery_search", { metadata: { interaction: "home_filter", filter: value, result_count: suggestedCreators().length } }), renderPlayerHome();
        return;
      }
      if (businessView)
        return event.preventDefault(), event.stopPropagation(), navigateProduct(businessView.dataset.lcBusinessView);
      if (discoveryFilter) {
        event.preventDefault();
        const value = discoveryFilter.dataset.lcDiscoveryFilter;
        if (!["for_you", "live", "following", "upcoming"].includes(value)) return;
        state.discoveryFilter = value, trackProductEvent("discovery_search", { metadata: { interaction: "filter", filter: value, result_count: suggestedCreators().length } }), state.socialView = "explore", renderSocialExplore();
        return;
      }
      if (liveSignals) {
        event.preventDefault(), await toggleLiveSignals(), renderAccount(), toast(state.liveSignalsEnabled ? "Live signals enabled" : "Live signals muted");
        return;
      }
      if (creatorSafety)
        return event.preventDefault(), renderCreatorSafety(creatorSafety.dataset.lcCreatorId, creatorSafety.dataset.lcCreatorSafety);
      if (safetyCenter)
        return event.preventDefault(), renderSocialSafety();
      if (confirmBlock) {
        event.preventDefault(), await blockCreator(confirmBlock.dataset.lcConfirmBlock), renderPlayerHome(), toast("Creator blocked");
        return;
      }
      if (blockedList)
        return event.preventDefault(), renderBlockedCreators();
      if (unblock) {
        event.preventDefault(), await unblockCreator(unblock.dataset.lcUnblock), renderBlockedCreators(), toast("Creator unblocked");
        return;
      }
      if (creatorProfileStatus) {
        event.preventDefault(), await setCreatorProfileStatus(creatorProfileStatus.dataset.lcCreatorProfileStatus), renderCreatorHome(), toast(state.creator.profile_status === "published" ? "Creator profile published" : "Creator profile is private");
        return;
      }
      if (sessionVisibility) {
        event.preventDefault(), await updateCreatorSession(sessionVisibility.dataset.lcSessionId, { visibility: sessionVisibility.dataset.lcSessionVisibility }), renderCreatorHome(), toast(sessionVisibility.dataset.lcSessionVisibility === "public" ? "Session published" : "Session is private");
        return;
      }
      if (sessionStatus) {
        event.preventDefault(), await updateCreatorSession(sessionStatus.dataset.lcSessionId, { status: sessionStatus.dataset.lcSessionStatus }), renderCreatorHome(), toast(sessionStatus.dataset.lcSessionStatus === "live" ? "Session is live" : "Session updated");
        return;
      }
      if (retry)
        return event.preventDefault(), retryLoad(retry);
      if (notification)
        return event.preventDefault(), openNotification(notification.dataset.lcNotification);
      if (notificationsRead) {
        event.preventDefault(), await markNotificationsRead(), routeHome();
        return;
      }
      if (demoPersona)
        return event.preventDefault(), enterDemo(demoPersona.dataset.lcDemoPersona);
      if (demoExit)
        return event.preventDefault(), clear(), resetDemoStore(), window.location.hash !== "#/product" && (window.location.hash = "#/product"), renderDemoEntry();
      if (demoSwitch && state.demo)
        return event.preventDefault(), renderDemoEntry();
      if (demoReset && state.demo) {
        event.preventDefault();
        const personaValue = state.demoPersona || "player";
        if (setupDemo(personaValue, !0), setProductHash(["demo", personaValue])) return;
        routeHome(), toast("Demo reset");
        return;
      }
      if (persona) {
        event.preventDefault();
        const value = persona.dataset.lcPersona;
        return state.demo ? value === "industry" ? renderIndustrySubtype() : enterDemo(value) : value === "industry" ? renderIndustrySubtype() : (await setCurrentPersona(value), routeHome());
      }
      if (industry)
        return event.preventDefault(), state.demo ? enterDemo(industry.dataset.lcIndustry) : (await setCurrentPersona("industry", industry.dataset.lcIndustry), routeHome());
      if (nav) {
        event.preventDefault();
        const value = nav.dataset.lcProduct;
        return ["profile", "account", "explore", "discover", "create", "creator", "activity", "home"].includes(value) ? (event.stopPropagation(), navigateProduct(value)) : value === "handoff" ? state.demo && state.selectedSession && setProductHash(["demo", state.demoPersona, "handoff", state.selectedSession]) ? void 0 : renderHandoff() : routeHome();
      }
      if (clearSearch)
        return event.preventDefault(), state.search = "", await loadCreators(), state.socialView = "explore", renderSocialExplore();
      if (openCreator) {
        const id = openCreator.dataset.lcOpenCreator;
        return state.demo && setProductHash(["demo", state.demoPersona, "creator", id]) ? void 0 : renderCreatorDetail(id);
      }
      if (live) {
        const id = live.dataset.lcLive;
        return state.demo && setProductHash(["demo", state.demoPersona, "live", id]) ? void 0 : renderLive(id);
      }
      if (operatorOutbound) {
        event.preventDefault();
        const id = operatorOutbound.dataset.lcOperatorOutbound, found = findSessionEntry(id), destination = state.handoffDestinations.get(id);
        if (!found || !isPresentedLive(found.session) || destination?.state !== "available") throw new Error("not_available");
        await trackProductEvent("product_open", {
          creatorId: found.entry.profile.id,
          sessionId: id,
          confidence: "direct",
          dedupeKey: `operator-outbound-click:${id}`,
          metadata: { surface: "operator_outbound_click" }
        }), window.location.assign(destination.url);
        return;
      }
      if (returnLive) {
        const id = returnLive.dataset.lcReturnLive, found = findSessionEntry(id);
        return trackProductEvent("handoff_return", { creatorId: found?.entry.profile.id, sessionId: id, confidence: "direct" }), state.demo && found && addDemoNotification(`Returned from operator context to ${profileName(found.entry.profile)}. Follow, content and next session stayed connected.`, id), state.demo && setProductHash(["demo", state.demoPersona, "live", id]) ? void 0 : renderLive(id);
      }
      if (follow)
        return await toggleFollow(follow.dataset.lcFollow), await loadCreators(), state.selectedCreator ? renderCreatorDetail(state.selectedCreator) : renderPlayerHome();
      if (creatorLiveAlerts) {
        event.preventDefault();
        const id = creatorLiveAlerts.dataset.lcCreatorLiveAlerts;
        await toggleCreatorLiveAlerts(id), renderCreatorDetail(id), toast(state.creatorLiveAlerts.get(id) === !1 ? "Live alerts muted for this Creator" : "Live alerts enabled for this Creator");
        return;
      }
      if (reminder)
        return await toggleReminder(reminder.dataset.lcReminder), await loadCreators(), state.selectedCreator ? renderCreatorDetail(state.selectedCreator) : renderPlayerHome();
      if (like) return likePost(like.dataset.lcLike);
      if (access)
        return await requestAccess(access.dataset.lcRequestAccess), state.demo ? (refreshDemoData(), renderIndustryHome()) : (await loadState(), renderIndustryHome());
    } catch (error) {
      toast(err(error)), await loadState().catch(() => {
      }), routeHome();
    }
  }
  async function mount({ client, profile, target = "product" }) {
    throw new Error("Private account functionality is unavailable in public demo.");
  }
  function clear() {
    state.client = null, state.discoveryFilter = "for_you", state.socialView = "home", state.creatorStudioView = "overview", state.businessView = "overview", state.profile = null, state.demo = !1, state.demoPersona = null, state.personas = [], state.current = null, state.player = null, state.creator = null, state.industry = null, state.sessions = [], state.creators = [], state.posts = [], state.follows = /* @__PURE__ */ new Set(), state.creatorLiveAlerts = /* @__PURE__ */ new Map(), state.reminders = /* @__PURE__ */ new Set(), state.notifications = [], state.returnSignalsAvailable = !0, state.creatorLiveAlertsAvailable = !0, state.liveSignalsEnabled = !0, state.accessRequests = [], state.blockedIds = /* @__PURE__ */ new Set(), state.blockedProfiles = [], state.search = "", state.loadError = null, state.retrying = !1, state.analyticsAvailable = !0, state.eventDedupe = /* @__PURE__ */ new Set(), hide();
  }
  function mountDemoEntry() {
    state.ready = !0;
    const parts = productParts();
    if (window.LC_APP_MODE === "public_demo" && parts[1] === "admin") return renderMissing("Role unavailable", "Admin is not part of the public demo.", "Back to Discover");
    if (parts[0] === "demo" && validDemoPersonas.has(parts[1])) {
      const preserveState = state.demo && state.demoPersona === parts[1], freshDemo = !state.demo;
      return preserveState || clear(), setupDemo(parts[1], freshDemo), renderProductTarget(parts.slice(2));
    }
    clear(), renderDemoEntry();
  }
  function renderProductTarget(parts = []) {
    let targetId;
    if (["creator", "live", "handoff"].includes(parts[0]) && parts[1])
      try {
        targetId = decodeURIComponent(parts[1]);
      } catch {
        return renderMissing("Invalid link", "This product link is malformed.", "Back to Discover");
      }
    return parts[0] === "creator" && targetId ? renderCreatorDetail(targetId) : parts[0] === "live" && targetId ? renderLive(targetId) : parts[0] === "handoff" && targetId ? renderHandoff(targetId) : parts[0] && !["demo"].includes(parts[0]) ? renderMissing("Route not found", "This product link is not available.", "Back to Discover") : routeHome();
  }
  document.addEventListener("submit", handleSubmit, !0), document.addEventListener("click", handleClick, !0), window.addEventListener("offline", syncConnectivity), window.addEventListener("online", () => {
    syncConnectivity(), state.loadError && retryLoad(null, !0);
  }), window.LCAppProduct = { mount, mountDemoEntry, clear, navigate: navigateProduct };
})();
